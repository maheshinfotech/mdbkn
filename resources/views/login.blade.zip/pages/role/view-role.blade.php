@php 
$pageName = "Role";
@endphp

@extends('layouts.backend' , ['pageName' => "Roles"])

{{-- @section('js')
  @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
  <x-reusables.app-header pageName="{{$pageName}}" :createButton="true" module="role" />
  
  <!-- Page Content -->
  <div class="content  mx-0 w-100">
    <!-- Info -->

    <!-- END Info -->

    <!-- Dynamic Table Full -->
    <div class="block block-rounded">

      <div class="block-content block-content-full">
        <div class="table-responsive">

            <!-- DataTables init on table by adding .js-dataTable-full class, functionality is initialized in js/pages/tables_datatables.js -->
            <table class="table table-bordered table-striped table-vcenter js-dataTable-full fs-sm">
                <thead>
                    <tr>
                        <th
                            class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Role Name
                        </th>

                        <th
                            class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Created Date
                        </th>
                        
                        <th
                            class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Status
                        </th>
                        <th
                            class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Action
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($listingData as $data)
                        <tr>
                            <td class="whitespace-nowrap ">
                                {{ $data->role_name }}
                            </td>
                            <td class="whitespace-nowrap ">
                                {{ $data->created_at }}
                            </td>
                            <td class="whitespace-nowrap ">
                                @if ($data->is_active)
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                @else
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-danger-light text-danger cursor-pointer">
                                        Inactive</div>
                                @endif

                            </td>
                            <td class="whitespace-nowrap">
                                <x-reusables.action-buttons :id="$data->id" module="role"
                                    :name="$data->role_name" />
                            </td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
            
        </div>
      </div>
    </div>
    <!-- END Dynamic Table Full -->
  </div>
  <!-- END Page Content -->
@endsection
