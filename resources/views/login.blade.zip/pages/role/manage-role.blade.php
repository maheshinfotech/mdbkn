
@php
    
    $is_update_form = $formData ? true : false;
    $action_url = $is_update_form ? url(config('app.admin_prefix') . "manage-role/$formData->id") : url(config('app.admin_prefix') . 'manage-role');
    $role_name = old('role_name', $formData->role_name ?? '');
    $is_active = old('is_active', $formData->is_active ?? '');
    $pageName = "Manage Roles";

@endphp

@extends('layouts.backend' , ['pageName' => "Manage Roles"])

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{$pageName}}" :createButton="true" module="role" />
    <div class="content  mx-0 w-100">
        <div class="block block-rounded">
            <div class="block-content block-content-full">
                <form action="{{ $action_url }}" method="post">
                    @csrf
                    @if ($is_update_form)
                        @method('PUT')
                    @endif

                    <div class="row justify-content-center">
                        <div class="col-6">
                            <label class="form-label" >Role Name</label>
                            <input class="form-control"
                                placeholder="Role Name" name="role_name" value="{{ $role_name }}" type="text" required>
                        </div>
                    </div>
                    <div class="row justify-content-center">

                        <div class="col-6 mt-4 text-center">
                            
                            <input  id="is_active" type="checkbox"
                            placeholder="Status" name="is_active" value="1" {{ $is_active ? "checked" : "" }} type="text" > 
                            <label class="form-label" for="is_active"> Active</label>
                            
                        </div>

                    </div>

                    <div class="d-flex justify-content-center space-x-2 mt-4">
                        <a href="{{ url(config('app.admin_prefix') . 'roles') }}"
                            class="btn min-w-[7rem] border border-slate-300 font-medium text-slate-700 hover:bg-slate-150 focus:bg-slate-150 active:bg-slate-150/80 dark:border-navy-450 dark:text-navy-100 dark:hover:bg-navy-500 dark:focus:bg-navy-500 dark:active:bg-navy-500/90">
                            Cancel
                        </a>
                        <button type="submit"
                            class="btn min-w-[7rem] bg-primary font-medium text-white hover:bg-primary-focus focus:bg-primary-focus active:bg-primary-focus/90 dark:bg-accent dark:hover:bg-accent-focus dark:focus:bg-accent-focus dark:active:bg-accent/90">
                            Save
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
@endsection
