@php
    $pageName = 'Welcome to BYOD';
@endphp

@extends('layouts.backend')

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{ $pageName }}" :createButton="false" module=""  />

    <!-- Page Content -->
    <div class="content">
            <h4 class="text-center ">Hello {{auth()->user()->name}}! Hope you are doing great.</h4>
    </div>
    <!-- END Page Content -->

@endsection
