@php
    $pageName = 'Trainers';
@endphp

@extends('layouts.backend')

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{ $pageName }}" :createButton="true" module="trainer" />

    <!-- Page Content -->
    <div class="content  mx-0 w-100">
        <!-- Info -->

        <!-- END Info -->

        <!-- Dynamic Table Full -->
        <div class="block block-rounded">

            <div class="block-content block-content-full">
                <div class="table-responsive">

                    <!-- DataTables init on table by adding .js-dataTable-full class, functionality is initialized in js/pages/tables_datatables.js -->
                    <table class="table table-bordered  table-vcenter js-dataTable-full fs-sm">
                        <thead>
                            <tr>
                                <th
                                    class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Tainer Name
                                </th>
                                {{-- <th
                                class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                User Name
                            </th> --}}

                                <th
                                    class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Email
                                </th>

                                <th
                                    class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Phone
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Created Date
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Expe.
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Status
                                </th>
                                {{-- <th
                                    class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Activity Status
                                </th> --}}
                                <th
                                    class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr>
                                <td class="whitespace-nowrap ">
                                    Trainer 1
                                </td>
                                {{-- <td class="whitespace-nowrap ">
                                John Doe
                            </td> --}}
                                <td class="whitespace-nowrap ">
                                    john@gmail.com
                                </td>
                                <td class="whitespace-nowrap ">
                                    9023232323
                                </td>
                                <td class="whitespace-nowrap ">
                                    11 Jan , 2023
                                </td>
                                <td class="whitespace-nowrap ">
                                    5
                                </td>
                                <td class="whitespace-nowrap ">

                                    <div class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>

                                </td>
                                {{-- <td class="whitespace-nowrap ">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Make Inactive">

                                        Make Inactive
                                    </a>

                                </td> --}}
                                <td class="whitespace-nowrap ">

                                    <div class="d-flex justify-content-center">

                                        <a href="{{ url(config('app.front_prefix') . 'apply-trainer') }}"
                                            x-tooltip.info="'Login As Trainer'" title="Login As Trainer" target="_blank"
                                            class="btn text-secondary mt-2">
                                            <i class="fa-solid fa-right-to-bracket"></i>
                                        </a>

                                        <a href="{{ url(config('app.admin_prefix') . 'trainer-classes') }}"
                                            x-tooltip.info="'View Classes of this Trainer'"
                                            title="View Classes of this Trainer" class="btn text-success mt-2">
                                            <i class="fa fa-users-viewfinder"></i>
                                        </a>

                                        <a href="{{ url(config('app.admin_prefix') . 'manage-trainer') }}"
                                            x-tooltip.info="'Edit Details'" class="btn text-info mt-2">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button class="btn text-success update-user-credentials mt-2"  title="Reset Password" data-id="eyJpdiI6IlgxSGlBRy9iVWNNWmcxK0pwUU9yZkE9PSIsInZhbHVlIjoibzhJemZuT0M1L3BtcDk0bCtWcWZCdz09IiwibWFjIjoiN2M4YzA1MmRkOWZkMWVmNjExYzExMGJlNmJjZTgwY2VhOWRjYzU5MzQ4M2Q3NjA5NWJjOTU4YjEwY2FkZjE2NSIsInRhZyI6IiJ9" data-name="John Doe">
                                            <i class="nav-main-link-icon si si-lock" data-bs-toggle="modal" data-bs-target="#forgot-password-modal"></i>
                                        </button>

                                        <button
                                            data-id="eyJpdiI6Im5pWlZsWWI0eHBXTFNWMEFlZEovTmc9PSIsInZhbHVlIjoiVnRpM0RCYk00VVJ6SmtvU3J0dkNCdz09IiwibWFjIjoiNDU1MjM4YmJjYzYyOTYyZDg1MjA1M2I1YzFkNDVlNjVmMzFiYTM3NDNhYmQ3MjUwY2QzNDYzMjc3YTRmNGY4NiIsInRhZyI6IiJ9"
                                            data-module="role" data-name="Delivery Boy" x-tooltip.error="'Delete Record'"
                                            class="delete-record btn text-danger js-swal-confirm mt-2">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>

                                </td>

                            </tr>
                            <tr>
                                <td class="whitespace-nowrap ">
                                    John Doe
                                </td>
                                {{-- <td class="whitespace-nowrap ">
                                Trainer 2
                            </td> --}}
                                <td class="whitespace-nowrap ">
                                    john@gmail.com
                                </td>
                                <td class="whitespace-nowrap ">
                                    9023232323
                                </td>
                                <td class="whitespace-nowrap ">
                                    11 Jan , 2023
                                </td>
                                <td class="whitespace-nowrap ">
                                    5
                                </td>
                                <td class="whitespace-nowrap ">

                                    <div class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-danger-light text-danger cursor-pointer">
                                        Inactive</div>

                                </td>
                                {{-- <td class="whitespace-nowrap ">

                                    <a class="btn btn-sm btn-alt-success js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Make Active"
                                        data-bs-original-title="Make Active">
                                        Make Active
                                    </a>

                                </td> --}}
                                <td class="whitespace-nowrap ">

                                    <div class="d-flex justify-content-center">

                                        <a href="{{ url(config('app.front_prefix') . 'apply-trainer') }}"
                                            x-tooltip.info="'Login As Trainer'" title="Login As Trainer" target="_blank"
                                            class="btn text-secondary mt-2">
                                            <i class="fa-solid fa-right-to-bracket"></i>
                                        </a>

                                        <a href="{{ url(config('app.admin_prefix') . 'trainer-classes') }}"
                                            x-tooltip.info="'View Classes of this Trainer'"
                                            title="View Classes of this Trainer" class="btn text-success mt-2">
                                            <i class="fa fa-users-viewfinder"></i>
                                        </a>

                                        <a href="{{ url(config('app.admin_prefix') . 'manage-trainer') }}"
                                            x-tooltip.info="'Edit Details'" class="btn text-info mt-2">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button class="btn text-success update-user-credentials mt-2" title="Reset Password" data-id="eyJpdiI6IlgxSGlBRy9iVWNNWmcxK0pwUU9yZkE9PSIsInZhbHVlIjoibzhJemZuT0M1L3BtcDk0bCtWcWZCdz09IiwibWFjIjoiN2M4YzA1MmRkOWZkMWVmNjExYzExMGJlNmJjZTgwY2VhOWRjYzU5MzQ4M2Q3NjA5NWJjOTU4YjEwY2FkZjE2NSIsInRhZyI6IiJ9" data-name="John Doe">
                                            <i class="nav-main-link-icon si si-lock" data-bs-toggle="modal" data-bs-target="#forgot-password-modal"></i>
                                        </button>

                                        <button
                                            data-id="eyJpdiI6Im5pWlZsWWI0eHBXTFNWMEFlZEovTmc9PSIsInZhbHVlIjoiVnRpM0RCYk00VVJ6SmtvU3J0dkNCdz09IiwibWFjIjoiNDU1MjM4YmJjYzYyOTYyZDg1MjA1M2I1YzFkNDVlNjVmMzFiYTM3NDNhYmQ3MjUwY2QzNDYzMjc3YTRmNGY4NiIsInRhZyI6IiJ9"
                                            data-module="role" data-name="Delivery Boy" x-tooltip.error="'Delete Record'"
                                            class="delete-record btn text-danger js-swal-confirm mt-2">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>

                                </td>

                            </tr>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <!-- END Dynamic Table Full -->
    </div>
    <!-- END Page Content -->

        {{-- Password reset modal --}}
        <div class="modal fade" id="forgot-password-modal" tabindex="-1" aria-labelledby="forgot-password-modal"
        style="display: none" aria-modal="true" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="block block-rounded block-transparent mb-0">
                    <div class="block-header block-header-default">
                        <h3 class="block-title">Reset the Password</h3>
                        <div class="block-options">
                            <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
                                <i class="fa fa-fw fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="block-content fs-sm p-5">
                        <form action="{{ url(config('app.admin_prefix') . '/update-user-password') }}" method="POST">
                            @csrf
                            <div class="row ">
                                <div class="col">

                                    <label class="form-label">
                                        <span>User Name</span>
                                    </label>
                                    <input type="hidden" class="company_id" name="user_id" value="">
                                    <input
                                        class="company_name form-control"
                                        placeholder="User Name" readonly type="text" />
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col">
                                    <label class="form-label">
                                        Password*
                                    </label>
                                        <input class="form-control" placeholder="Password" required name="password" type="password" />

                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col">

                                    <label class="form-label"> Confirm Password*</label>
                                        <input
                                            class="form-control"
                                            placeholder="Confirm Password" required name="password_confirmation"
                                            type="password" />

                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col d-flex justify-content-center gap-2">
                                    <button type="button" class="btn btn-sm btn-alt-secondary me-1"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- Reset password modal end --}}

@endsection
