@php
    $pageName = 'Class Details';
@endphp

@extends('layouts.backend')

@section('js')
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
@endsection

@section('content')
    <div class="content  mx-0 w-100">
        {{-- Basic Info Block --}}
        <div class="block block-rounded">
            <div class="block-content text-center">
                <div class="py-4">
                    <div class="mb-3">
                        <img class="img-avatar" src="{{ asset('media/avatars/avatar13.jpg') }}" alt="">
                    </div>
                    <h1 class="fs-lg mb-0">
                        <span>Self Defense Class</span>
                    </h1>
                    <p class="fs-sm fw-medium text-muted">Learn how to Protect yourself in trouble.</p>
                </div>
            </div>
            <div class="block-content bg-body-light text-center">
                <div class="row items-push text-uppercase">
                    <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">student Name</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">John Doe</a>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Class Fees</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">$20</a>
                    </div>
                    {{-- <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Available Seats</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">300</a>
                    </div> --}}
                    {{-- <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Total Students</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">28</a>
                    </div> --}}
                    <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Total Students</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">5</a>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Class Program</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">12 Mar, 2022 </a>
                    </div>
                </div>
            </div>
        </div>
        {{-- Basic Info Block End --}}

        {{-- Address Block --}}
        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">Address & Contact</h3>
            </div>
            <div class="block-content">
                <div class="row">
                    <div class="col-lg-6">
                        <!-- Billing Address -->
                        <div class="block block-rounded block-bordered">
                            <div class="block-header border-bottom">
                                <h3 class="block-title">Contact of Class</h3>
                            </div>
                            <div class="block-content">
                                <div class="fs-4 mb-1">Lorem Ispum</div>
                                <address class="fs-sm">
                                    Sunrise Str 620<br>
                                    Melbourne<br>
                                    Australia, 11-587<br><br>
                                    <i class="fa fa-phone"></i> (999) 888-55555<br>
                                    <i class="fa fa-envelope-o"></i> <a href="javascript:void(0)">loremispum@example.com</a>
                                </address>
                                <p class="mb-7">
                                    12 Jan 2023

                                    10:15 - 05:00
                                </p>
                            </div>
                        </div>
                        <!-- END Billing Address -->
                    </div>
                    <div class="col-lg-6">
                        <!-- Billing Address -->
                        <div class="block block-rounded block-bordered">
                            <div class="block-header border-bottom">
                                <h3 class="block-title">Address Of Map</h3>
                            </div>
                            <div class="block-content w-100 h-100">

                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1563313.938257045!2d-76.04373328429575!3d40.06765934415029!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c0fb959e00409f%3A0x2cd27b07f83f6d8d!2sNew%20Jersey%2C%20USA!5e0!3m2!1sen!2sin!4v1681370562355!5m2!1sen!2sin"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"
                                    referrerpolicy="no-referrer-when-downgrade"></iframe>

                            </div>
                        </div>
                        <!-- END Billing Address -->
                    </div>

                </div>
            </div>
        </div>
        {{-- End Address Block --}}

        {{-- Instructor Block --}}

        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">students Of Class</h3>
            </div>
            <div class="block-content">
                <div class="table-responsive">
                    <table class="table table-borderless table-striped table-vcenter">
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 100px;">Email ID</th>
                                <th class="d-none d-md-table-cell text-center">Name</th>
                                <th class="d-none d-sm-table-cell text-center">Phone No.</th>
                                <th class="d-none d-sm-table-cell text-center">Join date</th>
                                <th class="text-center">Address</th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student2@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 2</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student3@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 3</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        {{-- Request Block End --}}

        {{-- Key Tag Block --}}
        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">Key Tags</h3>
            </div>
            <div class="block-content">
                <div class="table-responsive">
                    <table class="table table-borderless table-striped table-vcenter">
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 100px;">KeyTag Number</th>
                                <th class="d-none d-md-table-cell text-center">Email</th>
                                <th class="d-none d-sm-table-cell text-end text-center">Zipcode</th>
                                <th class="d-none d-sm-table-cell text-end text-center">Address</th>
                                <th class="d-none d-sm-table-cell text-end text-center">State</th>
                                <th class="d-none d-sm-table-cell text-end text-center">Completion Date</th>

                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold">
                                        BYOD01-23
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    student1@gmail.com
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    334KP
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    Green House
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    Newyork
                                </td>
                                <td class="d-none d-sm-table-cell text-center fs-sm">18 Apr, 2022</td>

                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold">
                                        BYOD01-23
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    student2@gmail.com
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    334KP
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    Green House
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    Newyork
                                </td>
                                <td class="d-none d-sm-table-cell text-center fs-sm">18 Apr, 2022</td>

                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold">
                                        BYOD01-23
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    student3@gmail.com
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    334KP
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    Green House
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    Newyork
                                </td>
                                <td class="d-none d-sm-table-cell text-center fs-sm">18 Apr, 2022</td>

                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold">
                                        BYOD01-23
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    student4@gmail.com
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    334KP
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    Green House
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    Newyork
                                </td>
                                <td class="d-none d-sm-table-cell text-center fs-sm">18 Apr, 2022</td>

                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold">
                                        BYOD01-23
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    student5@gmail.com
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    334KP
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    Green House
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    Newyork
                                </td>
                                <td class="d-none d-sm-table-cell text-center fs-sm">18 Apr, 2022</td>

                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold">
                                        BYOD01-23
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    student6@gmail.com
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    334KP
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    Green House
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    Newyork
                                </td>
                                <td class="d-none d-sm-table-cell text-center fs-sm">18 Apr, 2022</td>

                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        {{-- Key Tag Block End --}}

        {{-- Reviews  Block --}}
        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">Reviews & Critiques</h3>
            </div>
            <div class="block-content">

                <div id="faq1" class="mb-5" role="tablist" aria-multiselectable="true">
                    <div class="block block-rounded block-bordered overflow-hidden mb-1">
                        <div class="block-header block-header-default d-flex justify-content-between" role="tab"
                            id="faq1_h1">

                            <a class="text-muted" data-bs-toggle="collapse" data-bs-parent="#faq1" href="#faq1_q1"
                                aria-expanded="false" aria-controls="faq1_q1">student1@gmail.com</a>

                            <div>

                                <i class="far text-warning fa-star"></i>
                                <i class="far text-warning  fa-star"></i>
                                <i class="far text-warning  fa-star"></i>
                                <i class="far text-warning fa-star"></i>
                                <i class="far  fa-star"></i>
                            </div>

                        </div>
                        <div id="faq1_q1" class="collapse" role="tabpanel" aria-labelledby="faq1_h1"
                            data-bs-parent="#faq1">
                            <div class="block-content d-flex justify-content-between">
                                <div>How clear was the delivery of information?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How engaging was your Trainer?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How was the Trainer’s attitude towards the students?</div>
                                <h4 class="text-warning">4/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How would you rate the Trainer’s use of class time?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How do you rate your Trainer’s knowledge of the material?</div>
                                <h4 class="text-warning">2/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How relevant is the material to you?</div>
                                <h4 class="text-warning">5/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How likely is it that you would recommend this class to a friend or colleague?</div>
                                <h4 class="text-warning">5/5</h4>
                            </div>
                        </div>
                    </div>

                    <div class="block block-rounded block-bordered overflow-hidden mb-1">
                        <div class="block-header block-header-default d-flex justify-content-between" role="tab"
                            id="faq1_h2">

                            <a class="text-muted" data-bs-toggle="collapse" data-bs-parent="#faq1" href="#faq1_q2"
                                aria-expanded="false" aria-controls="faq1_q2">student2@gmail.com</a>

                            <div>

                                <i class="far text-warning fa-star"></i>
                                <i class="far text-warning  fa-star"></i>
                                <i class="far text-warning  fa-star"></i>
                                <i class="far text-warning fa-star"></i>
                                <i class="far  fa-star"></i>
                            </div>

                        </div>
                        <div id="faq1_q2" class="collapse" role="tabpanel" aria-labelledby="faq1_h1"
                            data-bs-parent="#faq1">
                            <div class="block-content d-flex justify-content-between">
                                <div>How clear was the delivery of information?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How engaging was your Trainer?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How was the Trainer’s attitude towards the students?</div>
                                <h4 class="text-warning">4/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How would you rate the Trainer’s use of class time?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How do you rate your Trainer’s knowledge of the material?</div>
                                <h4 class="text-warning">2/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How relevant is the material to you?</div>
                                <h4 class="text-warning">5/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How likely is it that you would recommend this class to a friend or colleague?</div>
                                <h4 class="text-warning">5/5</h4>
                            </div>
                        </div>
                    </div>

                    <div class="block block-rounded block-bordered overflow-hidden mb-1">
                        <div class="block-header block-header-default d-flex justify-content-between" role="tab"
                            id="faq1_h3">

                            <a class="text-muted" data-bs-toggle="collapse" data-bs-parent="#faq1" href="#faq1_q3"
                                aria-expanded="false" aria-controls="faq1_q3">student3@gmail.com</a>

                            <div>

                                <i class="far text-warning fa-star"></i>
                                <i class="far text-warning  fa-star"></i>
                                <i class="far text-warning  fa-star"></i>
                                <i class="far text-warning fa-star"></i>
                                <i class="far  fa-star"></i>
                            </div>

                        </div>
                        <div id="faq1_q3" class="collapse" role="tabpanel" aria-labelledby="faq1_h1"
                            data-bs-parent="#faq1">
                            <div class="block-content d-flex justify-content-between">
                                <div>How clear was the delivery of information?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How engaging was your Trainer?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How was the Trainer’s attitude towards the students?</div>
                                <h4 class="text-warning">4/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How would you rate the Trainer’s use of class time?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How do you rate your Trainer’s knowledge of the material?</div>
                                <h4 class="text-warning">2/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How relevant is the material to you?</div>
                                <h4 class="text-warning">5/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How likely is it that you would recommend this class to a friend or colleague?</div>
                                <h4 class="text-warning">5/5</h4>
                            </div>
                        </div>
                    </div>

                    <div class="block block-rounded block-bordered overflow-hidden mb-1">
                        <div class="block-header block-header-default d-flex justify-content-between" role="tab"
                            id="faq1_h4">

                            <a class="text-muted" data-bs-toggle="collapse" data-bs-parent="#faq1" href="#faq1_q4"
                                aria-expanded="false" aria-controls="faq1_q4">student4@gmail.com</a>

                            <div>

                                <i class="far text-warning fa-star"></i>
                                <i class="far text-warning  fa-star"></i>
                                <i class="far text-warning  fa-star"></i>
                                <i class="far text-warning fa-star"></i>
                                <i class="far  fa-star"></i>
                            </div>

                        </div>
                        <div id="faq1_q4" class="collapse" role="tabpanel" aria-labelledby="faq1_h1"
                            data-bs-parent="#faq1">
                            <div class="block-content d-flex justify-content-between">
                                <div>How clear was the delivery of information?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How engaging was your Trainer?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How was the Trainer’s attitude towards the students?</div>
                                <h4 class="text-warning">4/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How would you rate the Trainer’s use of class time?</div>
                                <h4 class="text-warning">3/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How do you rate your Trainer’s knowledge of the material?</div>
                                <h4 class="text-warning">2/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How relevant is the material to you?</div>
                                <h4 class="text-warning">5/5</h4>
                            </div>
                            <div class="block-content d-flex justify-content-between">
                                <div>How likely is it that you would recommend this class to a friend or colleague?</div>
                                <h4 class="text-warning">5/5</h4>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        {{-- Key Tag Block End --}}

    </div>
@endsection
