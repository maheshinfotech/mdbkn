@php
    $pageName = 'Classes';
@endphp

@extends('layouts.backend')

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{ $pageName }}" :createButton="true" module="class" />

    <!-- Page Content -->
    <div class="content mx-0 w-100">
        <!-- Info -->

        <!-- END Info -->

        <div class="block block-rounded">
            <div class="block-content block-content-full">

                <form action="">
                    <div class="row">
                        <div class="col">
                            <label for="">Trainers</label>
                            <select name="" class="form-select js-select2" id="">
                                <option value="">Trainer1</option>
                                <option value="">Trainer2</option>
                                <option value="">Trainer3</option>
                            </select>
                        </div>
                        <div class="col">
                            <label for="">Instructors</label>
                            <select name="" class="form-select" id="">
                                <option value="">Instructor1</option>
                                <option value="">Instructor2</option>
                                <option value="">Instructor3</option>
                            </select>
                        </div>
                        <div class="col">
                            <label for="">Students</label>
                            <select name="" class="form-select" id="">
                                <option value="">Student1</option>
                                <option value="">Student2</option>
                                <option value="">Student3</option>
                            </select>
                        </div>
                        <div class="col my-auto">
                            <button class="btn btn-secondary">Reset</button>
                            <button class="btn btn-primary">Filter</button>
                        </div>
                    </div>
                </form>
                
            </div>
        </div>

        <!-- Dynamic Table Full -->
        <div class="block block-rounded">

            <div class="block-content block-content-full">
                <div class="table-responsive">

                    <!-- DataTables init on table by adding .js-dataTable-full class, functionality is initialized in js/pages/tables_datatables.js -->
                    <table class="table table-bordered table-striped table-vcenter js-dataTable-full fs-sm">
                        <thead>
                            <tr>
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Class Name
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Trainer
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Total Instructors
                                </th>

                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Course Price
                                </th>
                                {{-- <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Timings
                                </th> --}}

                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Status
                                </th>
                                {{-- <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Change Status
                                </th> --}}
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>

                            @foreach ($listingData as $course)
                                <tr>
                                    <td class="whitespace-nowrap">
                                        {{ $course->class_name }}
                                    </td>
                                    <td class="whitespace-nowrap">
                                        {{ $course->trainer->name ?? 'Not Working' }}
                                    </td>
                                    <td class="whitespace-nowrap">
                                        3
                                    </td>
                                    <td class="whitespace-nowrap">
                                        {{ $course->class_fees }}
                                    </td>
                                    {{-- <td class="whitespace-nowrap">
                                        {{ $course->class_timings }}
                                    </td> --}}
                                    <td class="whitespace-nowrap">

                                        @if ($course->is_active)
                                            <div class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                                Active</div>
                                        @else
                                            <div class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-danger-light text-danger cursor-pointer">
                                                DeActive</div>
                                        @endif

                                    </td>
                                    {{-- <td class="whitespace-nowrap">

                                        @if ($course->is_active)
                                            <button class="btn btn-sm btn-alt-danger">
                                                Make InActive</button>
                                        @else
                                            <button class="btn btn-sm btn-alt-success">
                                                Make Active</button>
                                        @endif

                                    </td> --}}

                                    <td class="whitespace-nowrap">
                                        <x-reusables.action-buttons :id="$course->id" module="class" :name="$course->name" />

                                    </td>

                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <!-- END Dynamic Table Full -->
    </div>
    <!-- END Page Content -->
@endsection
