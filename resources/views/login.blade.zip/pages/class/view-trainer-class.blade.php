@php
    $pageName = 'Trainer\'s Classes';
@endphp

@extends('layouts.backend')

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{!! $pageName !!}" :createButton="true" modulePlaceholder="Trainer Class"
        module="trainer-class" />

    <!-- Page Content -->
    <div class="content mx-0 w-100">
        <!-- Info -->

        <!-- END Info -->

        <div class="block block-rounded">
            <div class="block-content block-content-full">

                <form action="">
                    <div class="row">
                        <div class="col">
                            <label for="">Filter By Trainers </label>
                            <select name="" class="form-select js-select2" id="">
                                <option value="">Trainer1</option>
                                <option value="">Trainer2</option>
                                <option value="">Trainer3</option>
                            </select>
                        </div>
                        {{-- <div class="col">
                            <label for="">Instructors</label>
                            <select name="" class="form-select" id="">
                                <option value="">Instructor1</option>
                                <option value="">Instructor2</option>
                                <option value="">Instructor3</option>
                            </select>
                        </div> --}}
                        {{-- <div class="col">
                            <label for="">Students</label>
                            <select name="" class="form-select" id="">
                                <option value="">Student1</option>
                                <option value="">Student2</option>
                                <option value="">Student3</option>
                            </select>
                        </div> --}}
                        <div class="col my-auto my-auto mt-4">
                            <button class="btn btn-secondary">Reset</button>
                            <button class="btn btn-primary">Filter</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>

        <!-- Dynamic Table Full -->
        <div class="block block-rounded">

            <div class="block-content block-content-full">
                <div class="table-responsive">

                    <!-- DataTables init on table by adding .js-dataTable-full class, functionality is initialized in js/pages/tables_datatables.js -->
                    <table class="table table-bordered table-striped table-vcenter js-dataTable-full fs-sm">
                        <thead>
                            <tr>
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Class Name
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Trainer Name
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Total Instructors
                                </th>

                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Class Fees
                                </th>
                                {{-- <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Timings
                                </th> --}}

                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Status
                                </th>
                                {{-- <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Change Status
                                </th> --}}
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Class Name</td>
                                <td>Trainer 1</td>
                                <td>10</td>
                                <td>$100</td>
                                <td>
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                </td>
                                <td>
                                    <div class="d-flex justify-content-center gap-2">

                                        <a href="{{url('control-panel/trainer-class-detail')}}" title="view class detail"
                                            x-tooltip.info="'Edit Details'" class="btn text-success">
                                            <i class="fa fa-users-viewfinder"></i>
                                        </a>


                                        <a href="{{url('control-panel/manage-trainer-class')}}" title="edit class"
                                            x-tooltip.info="'Edit Details'" class="btn text-info">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button
                                            data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9"
                                            data-module="trainer-class" data-name="Trainer1" x-tooltip.error="'Delete Record'" title="delete record"
                                            class="delete-record btn text-danger js-swal-confirm">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>Class Name</td>
                                <td>Trainer 1</td>
                                <td>10</td>
                                <td>$100</td>
                                <td>
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                </td>
                                <td>
                                    <div class="d-flex justify-content-center gap-2">

                                        <a href="{{url('control-panel/trainer-class-detail')}}" title="view class detail"
                                            x-tooltip.info="'Edit Details'" class="btn text-success">
                                            <i class="fa fa-users-viewfinder"></i>
                                        </a>
                                        

                                        <a href="{{url('control-panel/manage-trainer-class')}}" title="edit class"
                                            x-tooltip.info="'Edit Details'" class="btn text-info">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button
                                            data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9"
                                            data-module="trainer-class" data-name="Trainer1" x-tooltip.error="'Delete Record'" title="delete record"
                                            class="delete-record btn text-danger js-swal-confirm">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>Class Name</td>
                                <td>Trainer 1</td>
                                <td>10</td>
                                <td>$100</td>
                                <td>
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                </td>
                                <td>
                                    <div class="d-flex justify-content-center gap-2">


                                        <a href="{{url('control-panel/trainer-class-detail')}}" title="view class detail"
                                            x-tooltip.info="'Edit Details'" class="btn text-success">
                                            <i class="fa fa-users-viewfinder"></i>
                                        </a>
                                        

                                        <a href="{{url('control-panel/manage-trainer-class')}}" title="edit class"
                                            x-tooltip.info="'Edit Details'" class="btn text-info">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button
                                            data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9"
                                            data-module="trainer-class" data-name="Trainer1" x-tooltip.error="'Delete Record'" title="delete record"
                                            class="delete-record btn text-danger js-swal-confirm">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>Class Name</td>
                                <td>Trainer 1</td>
                                <td>10</td>
                                <td>$100</td>
                                <td>
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                </td>
                                <td>
                                    <div class="d-flex justify-content-center gap-2">

                                        <a href="{{url('control-panel/trainer-class-detail')}}" title="view class detail"
                                            x-tooltip.info="'Edit Details'" class="btn text-success">
                                            <i class="fa fa-users-viewfinder"></i>
                                        </a>
                                        

                                        <a href="{{url('control-panel/manage-trainer-class')}}" title="edit class"
                                            x-tooltip.info="'Edit Details'" class="btn text-info">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button
                                            data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9"
                                            data-module="trainer-class" data-name="Trainer1" x-tooltip.error="'Delete Record'" title="delete record"
                                            class="delete-record btn text-danger js-swal-confirm">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>Class Name</td>
                                <td>Trainer 1</td>
                                <td>10</td>
                                <td>$100</td>
                                <td>
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                </td>
                                <td>
                                    <div class="d-flex justify-content-center gap-2">


                                        <a href="{{url('control-panel/trainer-class-detail')}}" title="view class detail"
                                            x-tooltip.info="'Edit Details'" class="btn text-success">
                                            <i class="fa fa-users-viewfinder"></i>
                                        </a>
                                        

                                        <a href="{{url('control-panel/manage-trainer-class')}}" title="edit class"
                                            x-tooltip.info="'Edit Details'" class="btn text-info">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button
                                            data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9"
                                            data-module="trainer-class" data-name="Trainer1" x-tooltip.error="'Delete Record'" title="delete record"
                                            class="delete-record btn text-danger js-swal-confirm">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <!-- END Dynamic Table Full -->
    </div>
    <!-- END Page Content -->
@endsection
