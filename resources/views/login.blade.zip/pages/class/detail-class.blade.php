@php
    $pageName = 'Detail Course';
@endphp

@extends('layouts.backend')

@section('content')
    <div class="content  mx-0 w-100">
        {{-- Basic Info Block --}}
        <div class="block block-rounded">
            <div class="block-content text-center">
                <div class="py-4">
                    <div class="mb-3">
                        <img class="img-avatar" src="{{ asset('media/avatars/avatar13.jpg') }}" alt="">
                    </div>
                    <h1 class="fs-lg mb-0">
                        <span>Self Defense Class</span>
                    </h1>
                    <p class="fs-sm fw-medium text-muted">Learn how to Protect yourself in trouble</p>
                </div>
            </div>
            <div class="block-content bg-body-light text-center">
                <div class="row items-push text-uppercase">
                    <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Trainer Name</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">John Doe</a>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Class Fees</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">20,000 INR</a>
                    </div>
                    {{-- <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Available Seats</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">300</a>
                    </div> --}}
                    <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Total Students</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">28</a>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="fw-semibold text-dark mb-1">Total Instructors</div>
                        <a class="link-fx text-primary" href="javascript:void(0)">5</a>
                    </div>
                </div>
            </div>
        </div>
        {{-- Basic Info Block End --}}

        {{-- Address Block --}}
        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">Address & Contact</h3>
            </div>
            <div class="block-content">
                <div class="row">
                    <div class="col-lg-6">
                        <!-- Billing Address -->
                        <div class="block block-rounded block-bordered">
                            <div class="block-header border-bottom">
                                <h3 class="block-title">Contact of Class</h3>
                            </div>
                            <div class="block-content">
                                <div class="fs-4 mb-1">John Parker</div>
                                <address class="fs-sm">
                                    Sunrise Str 620<br>
                                    Melbourne<br>
                                    Australia, 11-587<br><br>
                                    <i class="fa fa-phone"></i> (999) 888-55555<br>
                                    <i class="fa fa-envelope-o"></i> <a href="javascript:void(0)">company@example.com</a>
                                </address>
                            </div>
                        </div>
                        <!-- END Billing Address -->
                    </div>
                    <div class="col-lg-6">
                        <!-- Shipping Address -->
                        <div class="block block-rounded block-bordered">
                            <div class="block-header border-bottom">
                                <h3 class="block-title">Contact of Trainer</h3>
                            </div>
                            <div class="block-content">
                                <div class="fs-4 mb-1">John Parker</div>
                                <address class="fs-sm">
                                    Sunrise Str 620<br>
                                    Melbourne<br>
                                    Australia, 11-587<br><br>
                                    <i class="fa fa-phone"></i> (999) 888-55555<br>
                                    <i class="fa fa-envelope-o"></i> <a href="javascript:void(0)">company@example.com</a>
                                </address>
                            </div>
                        </div>
                        <!-- END Shipping Address -->
                    </div>
                </div>
            </div>
        </div>
        {{-- End Address Block --}}


        {{-- Instructor Block --}}

        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">Instructor Of Course</h3>
            </div>
            <div class="block-content">
                <div class="table-responsive">
                    <table class="table table-borderless table-striped table-vcenter">
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 100px;">Email ID</th>
                                <th class="d-none d-md-table-cell">Name</th>
                                <th class="d-none d-sm-table-cell text-end">Phone No.</th>
                                <th class="d-none d-sm-table-cell text-center">Join date</th>
                                <th>Address</th>


                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>


                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>instructor@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-trash text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>instructor@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-trash text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>instructor@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-trash text-danger"></i>
                                    </a>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        {{-- Request Block End --}}

        {{-- Request Block --}}

        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">Total User Requests</h3>
            </div>
            <div class="block-content">
                <div class="table-responsive">
                    <table class="table table-borderless table-striped table-vcenter">
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 100px;">ID</th>
                                <th class="d-none d-md-table-cell">Name</th>
                                <th class="d-none d-sm-table-cell text-end">Phone No.</th>
                                <th class="d-none d-sm-table-cell text-end">Instructor.</th>
                                <th class="d-none d-sm-table-cell text-center">Join date</th>
                                <th>Address</th>
                                <th>Status</th>

                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-success">Accepted</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-times text-danger"></i>
                                    </a>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-success">Accepted</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-times text-danger"></i>
                                    </a>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-danger">Requested</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-success js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-check text-success"></i>
                                    </a>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-danger">Requested</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-success js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-check text-success"></i>
                                    </a>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-success">Accepted</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-times text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-success">Accepted</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-times text-danger"></i>
                                    </a>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-success">Accepted</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-times text-danger"></i>
                                    </a>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-danger">Requested</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-success js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-check text-success"></i>
                                    </a>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-danger">Requested</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-success js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-check text-success"></i>
                                    </a>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-center fs-sm">
                                    <a class="fw-semibold" href="be_pages_ecom_product_edit.html">
                                        <strong>student1@gmail.com</strong>
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Student 1</a>
                                </td>
                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">9023124323</a>
                                </td>

                                <td class="d-none d-md-table-cell fs-sm">
                                    <a href="be_pages_ecom_product_edit.html">Instructor 1</a>
                                </td>
                                <td class="d-none d-sm-table-cell text-center fs-sm">15/07/2019</td>

                                <td class="d-none d-sm-table-cell text-center fs-sm">Green Hub, Newyork City</td>

                                <td>
                                    <span class="badge bg-success">Accepted</span>
                                </td>
                                <td class="text-center fs-sm">

                                    <a class="btn btn-sm btn-alt-danger js-bs-tooltip-enabled" href="javascript:void(0)"
                                        data-bs-toggle="tooltip" aria-label="Delete" data-bs-original-title="Delete">
                                        <i class="fa fa-fw fa-times text-danger"></i>
                                    </a>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        {{-- Request Block End --}}



    </div>
@endsection
