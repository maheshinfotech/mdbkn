@php
    
    $is_update_form = $formData ? true : false;
    $action_url = $is_update_form ? url(config('app.admin_prefix') . "manage-class/$formData->id") : url(config('app.admin_prefix') . 'manage-class');
    
    $pageName = 'Manage Trainer Class';
    
    $class_category = old('class_category', $formData->class_category ?? '');
    $class_name = old('class_name', $formData->class_name ?? '');
    $class_description = old('class_description', $formData->class_description ?? '');
    $class_timings = old('class_timings', $formData->class_timings ?? '');
    $class_fees = old('class_fees', $formData->class_fees ?? '');
    $class_contact = old('class_contact', $formData->class_contact ?? '');
    $class_trainer = old('class_trainer', $formData->class_trainer ?? '');
    $is_active = old('is_active', $formData->is_active ?? '');
    
@endphp

@extends('layouts.backend', ['pageName' =>$pageName])

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{ $pageName }}" :createButton="false" module="trainer-class" modulePlaceholder="Trainer's Class" />
    <div class="content  mx-0 w-100">
        <div class="block block-rounded">
            <div class="block-content block-content-full">
                <x-reusables.badge-alerts />
                <form action="{{ $action_url }}" method="post">
                    @csrf
                    @if ($is_update_form)
                        @method('PUT')
                    @endif

                    <div class="row mb-4">

                        <div class="col">
                            <label class="form-label">Class Name</label>
                            <input class="form-control " placeholder="Class Name" name="class_name"
                                value="{{ $class_name }}" type="text" required>
                        </div>

                        <div class="col">
                            <label class="form-label">Available Seats</label>
                            <input class="form-control " placeholder="Available Seats" name="class_name"
                                value="{{ $class_name }}" type="number" required>
                        </div>
                        <div class="col">
                            <label class="form-label">Last Registration Date</label>
                            <input class="form-control " placeholder="Last Registration Date" name="class_name"
                                value="{{ $class_name }}" type="date" required>
                        </div>
                        {{-- <div class="col">
                            <label class="form-label">Class Trainers</label>
                            <select name="class_trainer" class="form-control" required>
                                @foreach ($trainers as $trainer)
                                    <option value="{{ $trainer->id }}"
                                        {{ $trainer->id == $class_trainer ? 'selected' : '' }}>
                                        {{ $trainer->name }}</option>
                                @endforeach
                            </select>
                        </div> --}}
                    </div>
                    <div class="row mb-4">
                        <div class="col">
                            <label class="form-label">Class Description</label>
                            <textarea name="class_description" required class="form-control">{{ $class_description }}</textarea>
                        </div>
                    </div>

                    <div class="row mb-4">

                        <div class="col">
                            <label class="form-label">Class Fees</label>
                            <input class="form-control" placeholder="Class Fees" name="class_fees"
                                value="{{ $class_fees }}" type="number" required>
                        </div>
                        <div class="col">
                            <label class="form-label">Phone Number</label>
                            <input class="form-control " placeholder="Phone Number" value="{{ $class_contact }}"
                                name="class_contact" type="text" required>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col">
                            <label class="form-label">Zipcode</label>
                            <input placeholder="Zipcode" class="form-control" id="zipcode" name="class_zipcode"
                                {{ $is_active ? 'checked' : '' }} type="text" required>
                        </div>

                        <div class="col">
                            <label class="form-label">Address</label>
                            <input placeholder="Address" class="form-control" id="address" name="class_address"
                                {{ $is_active ? 'checked' : '' }} type="text" required>
                        </div>

                    </div>

                    <div class="row mb-4">

                        <div class="col">
                            <label class="form-label">Class Program</label>

                                <div class="input-daterange input-group js-datepicker-enabled" data-date-format="mm/dd/yyyy"
                                    data-week-start="1" data-autoclose="true" data-today-highlight="true">
                                    <input type="text" class="form-control datepicker" id="example-daterange1"
                                        name="example-daterange1" placeholder="From" data-week-start="1"
                                        data-autoclose="true" data-today-highlight="true">
                                    <span class="input-group-text fw-semibold">
                                        <i class="fa fa-fw fa-arrow-right"></i>
                                    </span>
                                    <input type="text" class="form-control datepicker" id="example-daterange2"
                                        name="example-daterange2" placeholder="To" data-week-start="1" data-autoclose="true"
                                        data-today-highlight="true">
                                </div>


                        </div>

                    </div>
                    {{-- <div class="row mb-4">
                        <div class="col ">
                            <label class="form-label">Class Timings</label>
                            <div class="d-flex justify-content-around">
                                <div class="d-flex flex-column">
                                    <span>Sunday</span>
                                    <input type="time" class="form-control" name=>
                                    <input type="time" class="form-control" name=>
                                </div>
                                <div class="d-flex flex-column">
                                    <span>Monday</span>
                                    <input type="time" class="form-control" name=>
                                    <input type="time" class="form-control" name=>
                                </div>
                                <div class="d-flex flex-column">
                                    <span>Tuesday</span>
                                    <input type="time" class="form-control" name=>
                                    <input type="time" class="form-control" name=>
                                </div>
                                <div class="d-flex flex-column">
                                    <span>Wednesday</span>
                                    <input type="time" class="form-control" name=>
                                    <input type="time" class="form-control" name=>
                                </div>
                                <div class="d-flex flex-column">
                                    <span>Thursday</span>
                                    <input type="time" class="form-control" name=>
                                    <input type="time" class="form-control" name=>
                                </div>
                                <div class="d-flex flex-column">
                                    <span>Friday</span>
                                    <input type="time" class="form-control" name=>
                                    <input type="time" class="form-control" name=>
                                </div>
                                <div class="d-flex flex-column">
                                    <span>Saturday</span>
                                    <input type="time" class="form-control" name=>
                                    <input type="time" class="form-control" name=>
                                </div>
                            </div>
                        </div>

                    </div> --}}

                    <div class="row mb-4">

                        <div class="col mt-4 text-center">
                            <input placeholder="User Name" id="is_active" name="is_active" value="1"
                                {{ $is_active ? 'checked' : '' }} type="checkbox" required>
                            <label class="form-label" for="is_active">Is Active</label>
                        </div>

                    </div>

                    <div class="row ">
                        <div class="col d-flex justify-content-center gap-3">

                            <a href="{{ url(config('app.admin_prefix') . 'classes') }}" class="btn btn-secondary">
                                Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                Save
                            </button>

                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
@endsection
