@extends('layouts.front-site.frontend')

@section('front-body')
    @if (true)
        <div class="hero-section full-screen has-map has-sidebar" style="height:538px">
            <div class="map-wrapper" style="height: 100%;">
                <div class="geo-location">
                    <i class="fa fa-map-marker"></i>
                </div>
                <div class="map" id="map-homepage"></div>
            </div>
            <!--end map-wrapper-->
            <div class="results-wrapper">
                <div class="sidebar-detail">
                    <div class="tse-scrollable">
                        <div class="tse-content">
                            <div class="sidebar-wrapper"></div>
                            <!--end sidebar-detail-content-->
                        </div>
                        <!--end tse-content-->
                    </div>
                    <!--end tse-scrollable-->
                </div>
                <!--end sidebar-detail-->
                <div class="results">
                    <div class="tse-scrollable">
                        <div class="tse-content">
                            <div class="section-title">
                                <section class="m-4">
                                    <h2>Searched Courses</h2>
                                    <div class="item" data-id="1">
                                        <a href="{{url(config('app.front_prefix').'details')}}">
                                            <div class="description">
                                                <figure>Average Price: $8 - $30</figure>
                                                <div class="label label-default">Restaurant</div>
                                                <h3>Judo Class</h3>
                                                <h4>63 Birch Street</h4>
                                            </div>
                                            <!--end description-->
                                            <div class="image bg-transfer"
                                                style="background-image: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAIQAuwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBAABAgUGB//EAEAQAAEDAgMEBQkGBQQDAAAAAAEAAgMEEQUSISIxcZETQVFhgQYUFSMykqGx0UJDUmKC8CQzcsHhRIOi8QclVP/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EAC0RAAIBAgMHAwMFAAAAAAAAAAABAgMRBBUhBRIxQVFSkRRCoWGx0RMiMkPh/9oADAMBAAIRAxEAPwDjObogvG14pt40QHtuTxCzNCwN3BYc31hTDWXPALL2bY4IAXkboqDPkjvbrZW1t7cEAJlu1wWZGm/imS3bKxI3ce9IBdo2TwQWj1iby6FCDbOKBi8g1VW2CiPFyFC3YKAAAaLOXUo7G6XVFqAAvaoRoivbqFHN0QABo3qg3Uo7W6LIbqUxAHN1Ue3cjFupVPbuQMFl0Wmt2St5VoNs1AAmN2VeRFa3ZWsqpDPQvbsoOT5p17dmyCW2cOIUkmmN08FhzdpGjbslZt6xAAZGajistboOCZkYssZ8kAKubtrMrdOaZc3bQ5W6nxQAsWb0IRl2c3s1ou4gX/ZTeXemsOw04jW+ZxksjZH03Sss4dV7jffWwCRSRwmB7rl0D2Mtdj3HfY7lbhs6L21Z5IyTxsdDVZcrQBG+OzeYP1Xn6zAMTpA4y0rnNF9qOzxx03eKe7JcROSb0OQwaLNtSitGys27kgMPGgWXDRGe3QDsWXjQIAE0KgNSjNbcLIF7lAAusqPG5btqrcNAmIEW6LQGi04K2t0QMy0bKuy00aKJoD1EjbDxQHDa8U5ILkdxQWs2jxQIkbdFkN20wxu/gFjLd5CQGHrDBp4IjhrzUYNnwQAC22sSs1v3IwG2pKNnwKAFSNUKF8kFR0kL3Me06OabWTQboShZNpxQB6nBvKinkidFirstQL5Zy3Ydfttu+S6NTTzuYHRvLbuzZ81r/v6rnYb5LwUtOKvGAHvLQRTnRrf6j18Pmt+m6efpI8Np56qSE5HdBEXNZbqzGwHNdMFJoyk4pjNR5N02KgtfIBKfZlYwZr9V+0cV5zCPJ2F0M0+IZnhkzomRRusHlps437Lr3NLWRto/OZQ6ExxXeJAAQQDc71w2EtwfD2wt0lj6Z7jvJdtf3UOCvqUmL1GE4ZiFFaKKKBu5krW5Sw/m7fFeLr6KWkqJIJmWfE7K6w04juXsoKg0U84LC5j2EuYB7WnYuBjdFUVdS2rirmGORosx5LMttO2xPJZS+hcfqcVo2RwWGjeuy/Cah0RfC6Oocy+ZsLsxA7bbz4LlBuhPaVI2CttK3jctW2lHjUJgDeFoDZK09uioeyUAZHsqrLbRsqrIEewe3VveUEN2jxTcg9nilyNvxVWEbDd/ghNHrHJgDU8Ahlu2UWAE9u4qBtrosnUFA3f4JALW2liQbPgUdo2zxQ5G9XcgYK2wnfJqmFTjlM14uxj+kcD+XX+yVA2CvQeQsLTiVTKfu4DbxcPonFXYnwEv/IWIPlLqSB5JaejIvYFx3n+y7OGYZFFC3D6Qfw1G1sZtYZ5LAknqvcgk94taxXm66jdP5RU/TNaGxSS1Ejbe10dnW525le58n4DTYXDJKS6WovO8ntdb/C62/wBqXXUwSvN/QoQsp2hsrrnqaBbx7l5iuxZ8jmNjhjayPZDBoW26gOr5LrY3WOp5oprXjJOcdrTvXl5ow+Rzonh4OuYbz32XPOfJGsYjdRIKiFs9O8hwuO8FcqKreGzMzWeZLX7B1kdiwal0FSBexJG7tSLw6KaZga7ZkcO869p7ljJ2NUrnUirHZ2mw2PZPsnwIWcbp4Js2IUYDGPt00R0LHdo7QdOfel6YgR5rZD2OcCVz8Qxh9C8tgly1EjSAd+VvDr/wlvXDdB22rDU9SjxtLxVc90tTJIY3gE3u69+PcvS4HXyYhSnzh+eaEhhcd7m20J5EeAV20uTzsdB40WQ3ZKK5uiot0PFIYIDZWSdUS2ysWQI9vK3QcUuW7Q4p6ZuyOKXyXIsrEWyMEXQ+jBeb35ppo2XITR6xAAJY7OG9QC3II8rVkMvyCQCgbaQhU9t7aI5Z6xbgldDI4B2QSNLC8C5YLjUcknoNK7EwwZN6f8naiWjxAyxRSTsc0slZGy5ym3ZwXdwCow674Z4myTh2YzPibtDgBb/tekZNA6PJTvZYG4aNPCycLS1uKaadjx2NUTxiMVVB7bHPNnaZmPble13wI7wu3RVULqBsUcmbIGtY8H9PztzTdRBTTNPnbb6ezexN/wDpePMNPSYhK/D2GBjz6xmY2cRp19dtO5OUnHmCSYevc8smp6gHI2LMHDqOpHzHJefbFI1glZcNBtm3C69fij4q7CjPT3dLYCZvWNd/DTeuFUyNlmpOnZ6mFjWloHUN/O55rGUlfU0S0PP4zJS0z4Z66rNPKRdjGszGQdRy/wB9EtQS0lfLUVFO+R7i4BzJABk010693xXiMZrampxKonqzmqnvPSO7Df2R3DcEDD6yakq2TRPLXNI3K5RvEmMrM+j1ssNPeKNhfORdsMYu495tu4ryTmzNxCokqWmSXPYmPaAFhbley7VPSVFfG2ofVPbA4h7IwdT36fNPU1JFALxAjS29YJS4Gt4rU4MeG1FRE9szA1zhdpJ3jqKLgeFyYdE/pnNMsjgSG7gBu15ruZLki37uqkZu4rWK3SJS3gDwqIuHBFkbZZA9pUSAA2VjKUYN0WLIA9/KzQJYt2hZdCRoNgUpl+ashFMboUNrfWFNhm/ihdHtHtQAF7bjmqY3ZJ7gjSNtbgVbW7JQMVy7ZQpma7t4KcihkllcI2F1tTYLr4fgXSNNRiLuhgZvBNnO+nzSA5WE4ZWVkv8ABjLkOspNms8V6OqDcOp71L2yTiwGVuVpPirrsRbBTMhw+0TG2tYW0/fXv1XCnkM8pkmka553kG/gFEpKOiGk2SvrX1T29HmB6MNcSb5rG+/uO5LtjeGlxs3TUkqTVMMJIF3v/DuA4rn1c0s7DnOn4RoFGsuJd0gk+IOjfmpHAlv2zuPaO8JySJr6aKsMEjYZACSG6C/V8+S5DGXb3r2HkvUQnAJ2VWsdO4hw7Wu1Hxuq3Eyd5o+UeVPkkKqsfV4ZK0l5u6N4ygntB/skMM8jZGVP/uJW07QQcjNtzu7TQL6NVRN6R5gBDSdAd9kriERMEEhbuuwn4j5pRd9BtcznlkYcWwNDYWgNYBusEJjdCEwxnyCyGb+KskBls5VINRxRSNrxWZW6jigAMrdFkDZKYe3ZQg3YKAAtbslByJuNuwVnJ3IGe7eNpBaB8Us/ENdIXcwlziLgdKZ5/UF1LCV37TjeOw0fcdew14oLQOkckBiU3VRvP6gs+f1IdfzM6/mVejr9pOYYbuOhI3ceKjW71zn19UdPM/8Akp59Vj/SfFHoq/aGYYbuOhNiPomjMjGjziW5jJ+wACM3fqTySWEz13Q9LWzySRv1ZE52v9VzfU8EtURzVzunlZYMa1vRE6kXFwOZWzU1R309u5c8MHiJ1HpwOieNw9OnH93E6kjKeW7+kkA7HOufgEqXC5bEMoHX1lJmqqh9wORQvOqoOJEI1/KVutn1uhzvaWH7hiVgvyWXt9WClX1VUT/LHun6obqmrLbZQB/Qqy+v0FmWG6jkbLN8V1/J/wBZ53Q5rGeMOZ3lpJtyJXmfOKwDS3uK4K6vp52Txus+M3Gx+9EZfXFmeG6s7j2WcUOsb/AgHqlHxB+iammjncZYmlrX7Yaeq43JHFjJ5gwxvynphfT8rlxUqUpVNxceB21K0IU/1HwFGM2dyprNopHPUD7/AE4KCSa/888l35dWODNMOHdGbnRVMw3CXJlP3zlh5lO+U/FGXVQzSgMPabLAZslAcJT94eZWC2W1ukPvFLLqnUeZ0egZosPFSyXETz95/wA1oU7/AMQ99LL6nUa2pS6H0D0ZIR/KaOLgoMKkJ/lxji5X6TBPtDgtDE4uskd914+fYp8LHXlFDmY9FSDqi94/RaGFy/ji5lFbXQO+8HOy353GN5spe28Z1Xj/AEFsvDLkxc4RKfvY28CVXoaT/wCpni0lM+exfjbzVefw/jb7wUZ3ju5eB5Vhu1+RcYK476tnuH6ogwJp088Z4Rf5W/SEV/bbzWTiUP4hySe28d3fCBbKwvb8s0PJ+M76vlH/AJVjAKcb53n9ICH6UiH2vgsnFovxfBQ9t41+/wC34LWy8L2fcZGBUo+/l+C2MFpBvllPiPokTi8A3vQ3Y1CNzj8Pqoe2Ma/eWtmYZew6wwii7XnxWvRNF+Y8SuO3HYSbbfHT6orcWY7c2Q8Bf5KMzxkv7GV6DDL2INiGDxubJNBM4PDdGWFjYJHyVkp8TpKgzQH1UxYWuduIGu7im48TaXjNHNl7m6rh4eBgPTvoYquaGWW74C27tftN6uPcFrSr1pwdpWkaOlT/AItaHrW4Zh530jOZWvRWG9dFCeIuufBigewOySsv9l7CCiivBO9/ulYesxS0c35F6WhygvA0cFwp2poafxYFoYJhPVQ0w4RhLekGj8R4NKv0kz8Lx+gperrv3Pyw9NR7V4Q16Ewk/wCkhHCMKHBMO+zBEP8AbCW9Ix9r/dKI3EoOu/xTVapPjL5f5K/SguCXhBPQlF1Rxj9AU9CUvYPcC3HiNH9rMP3xRxX4fb2xyK0jQctd/wCWTeK5fCPloqZLbwtCqlHWOSiiGkaoI2rm7QtCrl3bNj3KlFDSGX07yTaw4ITquZp9q/EKKLJpFXMedTE3zLXnEp3vKiimyAvpH/iKvfqVFFlNaFIjd6suINtFaiwKLEju1EEju1RRAzbJ5G7nEeKO2qlaBtXv2hRRXHiDSsGbO/LfRbbO/tCii1JsFbNJb2kWOR5PtFRRXETQZr3D7R5piE3Nj8yrUXVSSuQ+A0y1xdrTxF002OMtHq2e6FFF6MErHLPif//Z);">
                                                <img src="assets/img/items/1.jpg" alt="">
                                            </div>
                                            <!--end image-->
                                        </a>
                                        <div class="controls-more">
                                            <ul>
                                                <li><a href="#">Add to favorites</a></li>
                                                <li><a href="#">Add to watchlist</a></li>
                                                <li><a href="#" class="quick-detail">Quick detail</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!--end item-->
                                    <div class="item" data-id="2">
                                        <a href="{{url(config('app.front_prefix').'details')}}">
                                            <div class="description">
                                                <div class="label label-default">Restaurant</div>
                                                <h3>Karate Class</h3>
                                                <h4>4209 Glenview Drive</h4>
                                            </div>
                                            <!--end description-->
                                            <div class="image bg-transfer"
                                                style="background-image: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAHsAlgMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAQIDBgcIBQT/xAA9EAABAwMCAwQJAQUIAwAAAAABAAIDBAURBhIHITETFEFRIjJTYXGBkZKhwQgjM1KxFUNicoKy0uEWFyT/xAAXAQEAAwAAAAAAAAAAAAAAAAAAAQIE/8QAGxEBAQACAwEAAAAAAAAAAAAAAAECMQMRQQT/2gAMAwEAAhEDEQA/AN4oiICKC4KiaeKBhdLIxjRzy44QXFaNTCJuxMsYlxnZuG7HwWpeJHFqhitFTb9K1zn3My9i+YRuaImc9zmuIwTkAfPPgtBTyvnke+WR0srzufI85c4+8lB23nmpWtOAd2rLno2VlfLJM6lqnRRySvLnFmAQMnyJK2WgIiICIoBz0QSiIgImV41+1TYtPNBvN0pqVxbuaxzsvcPc0ZJ+iD2UXyWm4012ttPcKGR0lNUMD4nuYWlzT44PNfWgIiICgnClRjnlBRI9sTHSSOa1rQS5zjgALmTi/qwX3UE9JRuikoISNr2HfvIHMg+PiMjywDjr0vX0VPX07qerhimid1ZIwOB+RWK3Lh3abi1kUrnNpt5dJEyNo3gnOzOMhuQOnPkBkDkg1BpzgtfLpC+or54KKIxOMQ3bnOkx6IOOgz1KwG82as0/d3228wOhnhcO0ZnOQeeQR1BC6q1PqK16F06KmsLnBvoQQNPpzP64H6nwC5W1Bdqu/XSouNdNJLUTPLsPeXbG5JDR7h5INlaK1nSaOt9ymETZp6h8TacOftiEYLvEe4jkBnlzKyvTPHKz3CQQX2jktjycCZrjLEfjyBb9D8VzqrgAAwfX8EHattuNFdaVtVbauCqp3erLDIHtPzHivqXHOlNU3bSlxFbaaksOf3sLucco8nN/XqF17bqnvtvpqoxuj7eJsmx3VuRnCC+TnkFIGFS57I2F73BrAMlzjgBYVqbippWwNc3vwr6luR2FFiQ597s7R9fkgzcnAytaay4y2TT9SaO2w/2vVMOJOylDIme7fg5PwB+K1nrzi7ddSUht9BAbXQvP7zs5S6SVvkXYGB5gfDOFrqnhkqJmRwxuke4hrWMBLifIAdUHQurOL9vMIoNMzCWulYC6oP8ADi6EtaT6z8E48AfPosV0joSq11U9/vc0nc45szTOc50kx8WNc4kgeZPTAwMnl63DnhBbq7T5rNV0dUyrqHkxQukdE6KMdMj+Y8zz8MLblhs1DYLVT2y1xdlSwAhjS4k8zkkk9SSSUH100MdNTxwQMDIomhjGN6NaOQCuoiAigjKIJREQEREGjP2k6eqEtlrASaQNkix4NfyP5A/C0hkrrDi5a4LroC7tnALqaE1MTvFr2c+XxGR81ykBtGep8kFWBtzj955K0ckr1p9N3unt9PcZbXWCjqGb45xESwjzyOnzXnyRlh/esc1+M7SMZ96CaOUU1TFUGOKXs3hwjmbuY/B6OHiFm9dxh1pUyOMNyipIz0jgpo8Ae4uBP5WAkknJUtA6np/VB6t21Feb2c3i51dU3yklJaD7m9F5bi7OPIdFXDDLUzMhp4nyyvO1kcbdznHyAHVbv4bcHAxsdy1jFlwO6K35GB75Mdf8v18kGr9KaJv+rJALTQudADh1TKdkTP8AV4/AZK6H4dcObboyn7Y7au6yDElU5vqj+Vg8B+T+FmcEMdPEyKCNkcbBhrGNAAHkAriCAMKURAREQEREBQVKIKQeaqUYClB81yoYLlb6mhq27oKmJ0UjfNrhgrUdHwOs1vusdRdL6+aj3+hTvjbG5/8AhL93P5ALcqxzVWjrTqqopH3qOSeGla8MgEhY0udt9I4wcgN5c/FB69RU0VsoDNNLFTUdPHkvLg1jGAf0wuYeKsbv7XgrKlj2VlxbJWyNk9Zkb5CImkeGI2t5eZK2DdtDU3/sux2a2x11LbYqY1kk5qJJA9zT6rS8kAjDenMbvgrXGnRdFbNLOu1J3moqjXMdVVVVMZZSwtc0N3Ho0EtGPh5INGNbyyen9VkWg9NP1hqemtIkdDC4OfNK0Z7ONoycDzJwPiVjrjk+XwW4/wBm2iEl5vFcR/Bp2RA48XuJP+z8oNt6U0ZYtKQBloomtmxh9VJh0r/i79BgLIgmApQEREA8lSBkk+CYyeaqQEREBERAREQEREBERBTtGQepHQrEuLJDeHd8zGX/APz4xjOPSHP5dVl6xniXUd20Df5MZzQyM+4bf1QciHBwRkDx9y6H/ZxpgzS1yqgMdrXFgyOoaxv/ACK54c7PIdB+V1TwXpm03Di07RjtRJI73kvcgzhERAREQEREBERAREQERUk55BAyScBVKAMKUBERBGeaxHi0wv4d3wN8IAfo4LLcLG+JW3/wG/7uncZPrjkg5DAJOAuueF0XY8PrC0jGaRrvrk/quRycDA+ZXW/C+up67QFkkpXl7YqRkL/RIw9g2uH1BQZSeigEnqnVVICIiAVAKFAEEoiICKCcIglFClAREQEREBYHxJ1vpaz0dXZr3vrJp4PToYg4FzSOWXD1frlZ4vIv+mLJqOIR3q2wVQHJrnDD2/BwwR8ig5SsWlr9f3OqLFaJ6mON/rNaDGDn1cu5H4c/euvaGIQ0cEbYI6fbG0dlEAGs5dBjwSio6agpY6Wigjgp4htjiiaGtaPcAr6AiIgIiICIiAiIgIiIMUupgjuUzXvDGta3DQdowRzKvUcm2kp9oeQ5p9IU3aA+kcE+Pgvenpaeo2meGOQtOW72g4VZhjcBujacDA5eCycXz3Dludu0evD7xh7XbJXNLgcdx5kYyVegmjZtdKySVuMbe54OV63YQj+7Z9E7CLOezZ9FrSoZDA9jXCBgyM4LMFVd3h9jH9oU9hF7Nn0TsIvZt+iCO7wexj+0J3eD2Mf2hXUQWu7wexj+0J3aD2Mf2hXUQWu7wexj+0KDTQEfwY/tCvIg+CO3sjn3NOYzz2uwcFfUKaD2Mf2hXUUTGTQtd2g9jH9oXxVbWR1cLWinYx2S4Ob1/H6hekrb4YpHtfJGxzm+qSMkKuctnUHxBsZ2kSURHU+h/wBq9mhJxmnz8Wr6djcY2j6Jsb/KPoriyyOleDsZC7HI4AKK+AB0ARB//9k=);">
                                                <img src="assets/img/items/2.jpg" alt="">
                                            </div>
                                            <!--end image-->
                                        </a>
                                        <div class="controls-more">
                                            <ul>
                                                <li><a href="#">Add to favorites</a></li>
                                                <li><a href="#">Add to watchlist</a></li>
                                                <li><a href="#" class="quick-detail">Quick detail</a></li>
                                            </ul>
                                        </div>
                                        <!--end controls-more-->
                                    </div>
                                    <!--end item-->
                                    <div class="item" data-id="15">
                                        <figure class="ribbon">Top</figure>
                                        <a href="detail.html">
                                            <div class="description">
                                                <figure>Happy hour: 18:00 - 19:00</figure>
                                                <div class="label label-default">Bar &amp; Grill</div>
                                                <h3>Bambi Planet Houseboat Bar&amp; Grill </h3>
                                                <h4>3857 Losh Lane</h4>
                                            </div>
                                            <!--end description-->
                                            <div class="image bg-transfer"
                                                style="background-image: url(&quot;assets/img/items/3.jpg&quot;);">
                                                <img src="assets/img/items/3.jpg" alt="">
                                            </div>
                                            <!--end image-->
                                        </a>
                                        <div class="controls-more">
                                            <ul>
                                                <li><a href="#">Add to favorites</a></li>
                                                <li><a href="#">Add to watchlist</a></li>
                                                <li><a href="#" class="quick-detail">Quick detail</a></li>
                                            </ul>
                                        </div>
                                        <!--end controls-more-->
                                    </div>
                                    <!--end item-->
                                </section>
                                {{-- <h2>Search Results<span class="results-number"></span></h2> --}}
                                <a class="btn btn-primary" style="padding: 15px;margin:22px"
                                    href="{{ url(config('app.front_prefix') . 'details') }}"> Go To Detail Page</a>
                                <a class="btn btn-primary" style="padding: 15px;margin:22px"
                                    href="{{ url(config('app.front_prefix') . 'listings') }}"> Go To Map Result Page</a>
                            </div>
                            <!--end section-title-->
                            <div class="results-content"></div>
                            <!--end results-content-->
                        </div>
                        <!--end tse-content-->
                    </div>
                    <!--end tse-scrollable-->
                </div>
                <!--end results-->
            </div>
            <!--end results-wrapper-->

            <div class="form search-form vertical opacity-90" style="top: 144.5px;">
                <div class="container">
                    <form>
                        <div class="row">
                            <div class="col-md-4 col-sm-4">
                                <div class="wrapper clearfix">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="keyword"
                                            placeholder="Enter keyword">
                                    </div>
                                    <!--end form-group-->
                                    <div class="form-group">
                                        <select class="form-control selectpicker" name="city">
                                            <option value="">Location</option>
                                            <option value="1">New York</option>
                                            <option value="2">Washington</option>
                                            <option value="3">London</option>
                                            <option value="4">Paris</option>
                                        </select>
                                    </div>
                                    <!--end form-group-->
                                    <div class="form-group">
                                        <select class="form-control selectpicker" name="category">
                                            <option value="">Category</option>
                                            <option value="restaurant">Restaurant</option>
                                            <option value="car rental">Car Rental</option>
                                            <option value="relax">Relax</option>
                                            <option value="sport">Sport</option>
                                            <option value="wellness">Wellness</option>
                                        </select>
                                    </div>
                                    <!--end form-group-->
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="min-price"
                                            placeholder="Minimal Price">
                                    </div>
                                    <!--end form-group-->
                                    <div class="form-group">
                                        <button type="submit" data-ajax-response="map"
                                            data-ajax-data-file="assets/external/data_2.php" data-ajax-auto-zoom="1"
                                            class="btn btn-primary pull-right darker sa">Search Now<i
                                                class="fa fa-search"></i></button>
                                    </div>
                                    <!--end form-group-->
                                </div>
                                <!--end wrapper-->
                            </div>
                            <!--end col-md-4-->
                        </div>
                        <!--end row-->
                    </form>
                    <!--end form-hero-->
                </div>
                <!--end container-->
            </div>
            <!--end search-form-->

        </div>
        <!--end hero-section-->

        {{-- <section class="block">
                <div class="container">
                    <div class="center">
                        <div class="section-title">
                            <div class="center">
                                <h2>Searched Courses</h2>
                                <h3 class="subtitle">Fusce eu mollis dui, varius convallis mauris. Nam dictum id</h3>
                            </div>
                        </div>
                        <!--end section-title-->
                    </div>
                    <!--end center-->
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                            <div class="item" data-id="1">
                                <a href="detail.html">
                                    <div class="description">
                                        <figure>Average Price: $8 - $30</figure>
                                        <div class="label label-default">Restaurant</div>
                                        <h3>Marky’s Restaurant</h3>
                                        <h4>63 Birch Street</h4>
                                    </div>
                                    <!--end description-->
                                    <div class="image bg-transfer">
                                        <img src="assets/img/items/1.jpg" alt="">
                                    </div>
                                    <!--end image-->
                                </a>
                                <div class="additional-info">
                                    <div class="rating-passive" data-rating="4">
                                        <span class="stars"></span>
                                        <span class="reviews">6</span>
                                    </div>
                                    <div class="controls-more">
                                        <ul>
                                            <li><a href="#">Add to favorites</a></li>
                                            <li><a href="#">Add to watchlist</a></li>
                                            <li><a href="#" class="quick-detail">Quick detail</a></li>
                                        </ul>
                                    </div>
                                    <!--end controls-more-->
                                </div>
                                <!--end additional-info-->
                            </div>
                            <!--end item-->
                        </div>
                        <!--<end col-md-3-->
                        <div class="col-md-3 col-sm-3">
                            <div class="item" data-id="2">
                                <a href="detail.html">
                                    <div class="description">
                                        <div class="label label-default">Restaurant</div>
                                        <h3>Ironapple</h3>
                                        <h4>4209 Glenview Drive</h4>
                                    </div>
                                    <!--end description-->
                                    <div class="image bg-transfer">
                                        <img src="assets/img/items/2.jpg" alt="">
                                    </div>
                                    <!--end image-->
                                </a>
                                <div class="additional-info">
                                    <div class="rating-passive" data-rating="3">
                                        <span class="stars"></span>
                                        <span class="reviews">13</span>
                                    </div>
                                    <div class="controls-more">
                                        <ul>
                                            <li><a href="#">Add to favorites</a></li>
                                            <li><a href="#">Add to watchlist</a></li>
                                            <li><a href="#" class="quick-detail">Quick detail</a></li>
                                        </ul>
                                    </div>
                                    <!--end controls-more-->
                                </div>
                                <!--end additional-info-->
                            </div>
                            <!--end item-->
                        </div>
                        <!--<end col-md-3-->
                        <div class="col-md-6 col-sm-6">
                            <div class="item" data-id="15">
                                <figure class="ribbon">Top</figure>
                                <a href="detail.html">
                                    <div class="description">
                                        <figure>Happy hour: 18:00 - 19:00</figure>
                                        <div class="label label-default">Bar & Grill</div>
                                        <h3>Bambi Planet Houseboat Bar& Grill </h3>
                                        <h4>3857 Losh Lane</h4>
                                    </div>
                                    <!--end description-->
                                    <div class="image bg-transfer">
                                        <img src="assets/img/items/3.jpg" alt="">
                                    </div>
                                    <!--end image-->
                                </a>
                                <div class="additional-info">
                                    <figure class="circle" title="Featured"><i class="fa fa-check"></i></figure>
                                    <div class="rating-passive" data-rating="5">
                                        <span class="stars"></span>
                                        <span class="reviews">56</span>
                                    </div>
                                    <div class="controls-more">
                                        <ul>
                                            <li><a href="#">Add to favorites</a></li>
                                            <li><a href="#">Add to watchlist</a></li>
                                            <li><a href="#" class="quick-detail">Quick detail</a></li>
                                        </ul>
                                    </div>
                                    <!--end controls-more-->
                                </div>
                                <!--end additional-info-->
                            </div>
                            <!--end item-->
                        </div>
                        <!--<end col-md-3-->
                        <div class="col-md-4 col-sm-4">
                            <div class="item" data-id="3">
                                <figure class="ribbon">Top</figure>
                                <a href="detail.html">
                                    <div class="description">
                                        <figure>Starts at: 19:00</figure>
                                        <div class="label label-default">Event</div>
                                        <h3>Food Festival</h3>
                                        <h4>840 My Drive</h4>
                                    </div>
                                    <!--end description-->
                                    <div class="image bg-transfer">
                                        <img src="assets/img/items/4.jpg" alt="">
                                    </div>
                                    <!--end image-->
                                </a>
                                <div class="additional-info">
                                    <figure class="circle" title="Featured"><i class="fa fa-check"></i></figure>
                                    <div class="rating-passive" data-rating="5">
                                        <span class="stars"></span>
                                        <span class="reviews">12</span>
                                    </div>
                                    <div class="controls-more">
                                        <ul>
                                            <li><a href="#">Add to favorites</a></li>
                                            <li><a href="#">Add to watchlist</a></li>
                                            <li><a href="#" class="quick-detail">Quick detail</a></li>
                                        </ul>
                                    </div>
                                    <!--end controls-more-->
                                </div>
                                <!--end additional-info-->
                            </div>
                            <!--end item-->
                        </div>
                        <!--<end col-md-4-->
                        <div class="col-md-3 col-sm-3">
                            <div class="item" data-id="4">
                                <a href="detail.html">
                                    <div class="description">
                                        <div class="label label-default">Lounge</div>
                                        <h3>Cosmopolit</h3>
                                        <h4>2896 Ripple Street</h4>
                                    </div>
                                    <!--end description-->
                                    <div class="image bg-transfer">
                                        <img src="assets/img/items/5.jpg" alt="">
                                    </div>
                                    <!--end image-->
                                </a>
                                <div class="additional-info">
                                    <div class="rating-passive" data-rating="5">
                                        <span class="stars"></span>
                                        <span class="reviews">43</span>
                                    </div>
                                    <div class="controls-more">
                                        <ul>
                                            <li><a href="#">Add to favorites</a></li>
                                            <li><a href="#">Add to watchlist</a></li>
                                            <li><a href="#" class="quick-detail">Quick detail</a></li>
                                        </ul>
                                    </div>
                                    <!--end controls-more-->
                                </div>
                                <!--end additional-info-->
                            </div>
                            <!--end item-->
                        </div>
                        <!--<end col-md-3-->
                        <div class="col-md-5 col-sm-5">
                            <div class="item" data-id="6">
                                <a href="detail.html">
                                    <div class="description">
                                        <figure>Free entry</figure>
                                        <div class="label label-default">Concert</div>
                                        <h3>Stand Up Show</h3>
                                        <h4>371 Kinney Street</h4>
                                    </div>
                                    <!--end description-->
                                    <div class="image bg-transfer">
                                        <img src="assets/img/items/6.jpg" alt="">
                                    </div>
                                    <!--end image-->
                                </a>
                                <div class="additional-info">
                                    <div class="rating-passive" data-rating="0">
                                        <span class="stars"></span>
                                        <span class="reviews">0</span>
                                    </div>
                                    <div class="controls-more">
                                        <ul>
                                            <li><a href="#">Add to favorites</a></li>
                                            <li><a href="#">Add to watchlist</a></li>
                                            <li><a href="#" class="quick-detail">Quick detail</a></li>
                                        </ul>
                                    </div>
                                    <!--end controls-more-->
                                </div>
                                <!--end additional-info-->
                            </div>
                            <!--end item-->
                        </div>
                        <!--<end col-md-3-->
                    </div>
                    <!--end row-->
                    <div class="center">
                        <a href="listing.html" class="btn btn-primary btn-light-frame btn-rounded btn-framed arrow">View
                            all listings</a>
                    </div>
                    <!--end center-->
                </div>
                <!--end container-->
            </section> --}}
        <!--end block-->
        <div class="container">
            <hr>
        </div>
        @if (false)
            <section class="block">
                <div class="container">
                    <div class="section-title">
                        <div class="center">
                            <h2>Browse Our Listings</h2>
                        </div>
                    </div>
                    <!--end section-title-->
                    <div class="categories-list">
                        <div class="row">
                            <div class="col-md-3 col-sm-3">
                                <div class="list-item">
                                    <div class="title">
                                        <div class="icon"><i class="fa fa-paint-brush"></i></div>
                                        <h3><a href="#">Arts & Humanities</a></h3>
                                    </div>
                                    <!--end title-->
                                    <ul>
                                        <li><a href="">Photography</a>
                                            <figure class="count">3</figure>
                                        </li>
                                        <li><a href="">History</a>
                                            <figure class="count">2</figure>
                                        </li>
                                        <li><a href="">Literature</a>
                                            <figure class="count">4</figure>
                                        </li>
                                    </ul>
                                </div>
                                <!--end list-item-->
                            </div>
                            <!--end col-md-3-->
                            <div class="col-md-3 col-sm-3">
                                <div class="list-item">
                                    <div class="title">
                                        <div class="icon"><i class="fa fa-suitcase"></i></div>
                                        <h3><a href="#">Business & Economy</a></h3>
                                    </div>
                                    <!--end title-->
                                    <ul>
                                        <li><a href="">Business to Business</a>
                                            <figure class="count">6</figure>
                                        </li>
                                        <li><a href="">Finance</a>
                                            <figure class="count">4</figure>
                                        </li>
                                        <li><a href="">Shopping</a>
                                            <figure class="count">3</figure>
                                        </li>
                                        <li><a href="">Jobs</a>
                                            <figure class="count">5</figure>
                                        </li>
                                    </ul>
                                </div>
                                <!--end list-item-->
                            </div>
                            <!--end col-md-3-->
                            <div class="col-md-3 col-sm-3">
                                <div class="list-item">
                                    <div class="title">
                                        <div class="icon"><i class="fa fa-desktop"></i></div>
                                        <h3><a href="#">Computer & Internet</a></h3>
                                    </div>
                                    <!--end title-->
                                    <ul>
                                        <li><a href="">Hardware</a>
                                            <figure class="count">10</figure>
                                        </li>
                                        <li><a href="">Software</a>
                                            <figure class="count">4</figure>
                                        </li>
                                        <li><a href="">Websites</a>
                                            <figure class="count">6</figure>
                                        </li>
                                        <li><a href="">Games</a>
                                            <figure class="count">7</figure>
                                        </li>
                                    </ul>
                                </div>
                                <!--end list-item-->
                            </div>
                            <!--end col-md-3-->
                            <div class="col-md-3 col-sm-3">
                                <div class="list-item">
                                    <div class="title">
                                        <div class="icon"><i class="fa fa-graduation-cap"></i></div>
                                        <h3><a href="#">Education</a></h3>
                                    </div>
                                    <!--end title-->
                                    <ul>
                                        <li><a href="">Colleges</a>
                                            <figure class="count">8</figure>
                                        </li>
                                        <li><a href="">K-12</a>
                                            <figure class="count">7</figure>
                                        </li>
                                        <li><a href="">Distance Learning </a>
                                            <figure class="count">2</figure>
                                        </li>
                                    </ul>
                                </div>
                                <!--end list-item-->
                            </div>
                            <!--end col-md-3-->
                        </div>
                        <!--end row-->
                        <div class="row">
                            <div class="col-md-3 col-sm-3">
                                <div class="list-item">
                                    <div class="title">
                                        <div class="icon"><i class="fa fa-television"></i></div>
                                        <h3><a href="#">Entertainment</a></h3>
                                    </div>
                                    <!--end title-->
                                    <ul>
                                        <li><a href="">Movies</a>
                                            <figure class="count">6</figure>
                                        </li>
                                        <li><a href="">TV Shows</a>
                                            <figure class="count">9</figure>
                                        </li>
                                        <li><a href="">Music</a>
                                            <figure class="count">1</figure>
                                        </li>
                                        <li><a href="">Humor </a>
                                            <figure class="count">4</figure>
                                        </li>
                                    </ul>
                                </div>
                                <!--end list-item-->
                            </div>
                            <!--end col-md-3-->
                            <div class="col-md-3 col-sm-3">
                                <div class="list-item">
                                    <div class="title">
                                        <div class="icon"><i class="fa fa-university"></i></div>
                                        <h3><a href="#">Government</a></h3>
                                    </div>
                                    <!--end title-->
                                    <ul>
                                        <li><a href="">Elections</a>
                                            <figure class="count">3</figure>
                                        </li>
                                        <li><a href="">Military</a>
                                            <figure class="count">2</figure>
                                        </li>
                                        <li><a href="">Law</a>
                                            <figure class="count">6</figure>
                                        </li>
                                        <li><a href="">Taxes</a>
                                            <figure class="count">7</figure>
                                        </li>
                                    </ul>
                                </div>
                                <!--end list-item-->
                            </div>
                            <!--end col-md-3-->
                            <div class="col-md-3 col-sm-3">
                                <div class="list-item">
                                    <div class="title">
                                        <div class="icon"><i class="fa fa-heart"></i></div>
                                        <h3><a href="#">Health</a></h3>
                                    </div>
                                    <!--end title-->
                                    <ul>
                                        <li><a href="">Disease</a>
                                            <figure class="count">1</figure>
                                        </li>
                                        <li><a href="">Drugs</a>
                                            <figure class="count">5</figure>
                                        </li>
                                        <li><a href="">Fitness</a>
                                            <figure class="count">4</figure>
                                        </li>
                                        <li><a href="">Nutrition </a>
                                            <figure class="count">8</figure>
                                        </li>
                                    </ul>
                                </div>
                                <!--end list-item-->
                            </div>
                            <!--end col-md-3-->
                            <div class="col-md-3 col-sm-3">
                                <div class="list-item">
                                    <div class="title">
                                        <div class="icon"><i class="fa fa-newspaper-o"></i></div>
                                        <h3><a href="#">News & Media</a></h3>
                                    </div>
                                    <!--end title-->
                                    <ul>
                                        <li><a href="">Newspapers</a>
                                            <figure class="count">5</figure>
                                        </li>
                                        <li><a href="">Radio</a>
                                            <figure class="count">9</figure>
                                        </li>
                                        <li><a href="">Weather</a>
                                            <figure class="count">3</figure>
                                        </li>
                                        <li><a href="">Blogs</a>
                                            <figure class="count">4</figure>
                                        </li>
                                    </ul>
                                </div>
                                <!--end list-item-->
                            </div>
                            <!--end col-md-3-->
                        </div>
                        <!--end row-->
                    </div>
                    <!--end categories-list-->
                </div>
                <!--end container-->
            </section>
        @endif
        <!--end block-->
        @if (false)
            <section class="block big-padding">
                <div class="container">
                    <div class="vertical-aligned-elements">
                        <div class="element width-50">
                            <h3>Subscribe and be notified about new locations</h3>
                        </div>
                        <!--end element-->
                        <div class="element width-50">
                            <form class="form form-email inputs-underline" id="form-subscribe">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="email" placeholder="Your email"
                                        required="">
                                    <span class="input-group-btn">
                                        <button class="btn" type="submit"><i class="arrow_right"></i></button>
                                    </span>
                                </div><!-- /input-group -->
                            </form>
                            <!--end form-->
                        </div>
                        <!--end element-->
                    </div>
                    <!--end vertical-aligned-elements-->
                </div>
                <!--end container-->
                <div class="background-wrapper">
                    <div class="background-color background-color-black opacity-5"></div>
                </div>
                <!--end background-wrapper-->
            </section>
        @endif
        <!--end block-->
        {{-- <section class="block background-is-dark">
                <div class="container">
                    <div class="section-title vertical-aligned-elements">
                        <div class="element">
                            <h2>Promoted Locations</h2>
                        </div>
                        <div class="element text-align-right">
                            <a href="#" class="btn btn-framed btn-rounded btn-default invisible-on-mobile">Promote
                                yours</a>
                            <div id="gallery-nav"></div>
                        </div>
                    </div>
                    <!--end section-title-->
                </div>
                <div class="gallery featured">
                    <div class="owl-carousel" data-owl-items="6" data-owl-loop="1" data-owl-auto-width="1"
                        data-owl-nav="1" data-owl-dots="1" data-owl-nav-container="#gallery-nav">
                        <div class="item featured" data-id="1">
                            <a href="detail.html">
                                <div class="description">
                                    <figure>Average Price: $8 - $30</figure>
                                    <div class="label label-default">Restaurant</div>
                                    <h3>Marky’s Restaurant</h3>
                                    <h4>63 Birch Street</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/1.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="4">
                                    <span class="stars"></span>
                                    <span class="reviews">6</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                        <div class="item featured" data-id="23">
                            <a href="detail.html">
                                <div class="description">
                                    <figure>Starts from: $14.99</figure>
                                    <div class="label label-default">Trip</div>
                                    <h3>Nascar Racing</h3>
                                    <h4>london Airport</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/11.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="4">
                                    <span class="stars"></span>
                                    <span class="reviews">6</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                        <div class="item featured" data-id="3">
                            <a href="detail.html">
                                <div class="description">
                                    <figure>
                                        <span><i class="fa fa-calendar"></i>12.08.2016</span>
                                        <span><i class="fa fa-clock-o"></i>08:00</span>
                                    </figure>
                                    <div class="label label-default">Event</div>
                                    <h3>Food Festival</h3>
                                    <h4>63 Birch Street</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/4.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="4">
                                    <span class="stars"></span>
                                    <span class="reviews">6</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                        <div class="item featured" data-id="4">
                            <a href="detail.html">
                                <div class="description">
                                    <figure>Average Price: $8 - $30</figure>
                                    <div class="label label-default">Lounge</div>
                                    <h3>Cosmopolit</h3>
                                    <h4>4696 Jim Rosa Lane</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/5.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="4">
                                    <span class="stars"></span>
                                    <span class="reviews">6</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                        <div class="item featured" data-id="6">
                            <a href="detail.html">
                                <div class="description">
                                    <div class="label label-default">Event</div>
                                    <h3>Stand Up Show</h3>
                                    <h4>63 Birch Street</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/6.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="4">
                                    <span class="stars"></span>
                                    <span class="reviews">6</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                        <div class="item featured" data-id="8">
                            <a href="detail.html">
                                <div class="description">
                                    <figure>Get to know yor town!</figure>
                                    <div class="label label-default">Event</div>
                                    <h3>City Tour</h3>
                                    <h4>63 Birch Street</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/10.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="4">
                                    <span class="stars"></span>
                                    <span class="reviews">6</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                        <div class="item featured" data-id="5">
                            <a href="detail.html">
                                <div class="description">
                                    <div class="label label-default">Real Estate</div>
                                    <h3>Beautiful Luxury Villa</h3>
                                    <h4>59 Water Street</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/28.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="3">
                                    <span class="stars"></span>
                                    <span class="reviews">12</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                        <div class="item featured" data-id="7">
                            <a href="detail.html">
                                <div class="description">
                                    <figure>Average Price: $8 - $30</figure>
                                    <div class="label label-default">Bar</div>
                                    <h3>Fiesta Bar</h3>
                                    <h4>3524 Bryan Avenue</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/12.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="5">
                                    <span class="stars"></span>
                                    <span class="reviews">17</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                        <div class="item featured" data-id="1">
                            <a href="detail.html">
                                <div class="description">
                                    <div class="label label-default">Adrenaline</div>
                                    <h3>Senior C# Developer</h3>
                                    <h4>ERF Solutions</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/16.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="4">
                                    <span class="stars"></span>
                                    <span class="reviews">6</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                    </div>
                </div>
                <!--end gallery-->
                <div class="background-wrapper">
                    <div class="background-color background-color-default"></div>
                </div>
                <!--end background-wrapper-->
            </section> --}}
        <!--end block-->

        <section class="block">
            <div class="container">
                <div class="section-title">
                    <h2>Events Near You</h2>
                </div>
                <!--end section-title-->
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                        <div class="text-element event">
                            <div class="date-icon">
                                <figure class="day">22</figure>
                                <figure class="month">Jun</figure>
                            </div>
                            <h4><a href="detail.html">Lorem ipsum dolor sit amet</a></h4>
                            <figure class="date"><i class="icon_clock_alt"></i>08:00</figure>
                            <p>Ut nec vulputate enim. Nulla faucibus convallis dui. Donec arcu enim, scelerisque.</p>
                            <a href="detail.html" class="link arrow">More</a>
                        </div>
                        <!--end text-element-->
                    </div>
                    <!--end col-md-4-->
                    <div class="col-md-4 col-sm-4">
                        <div class="text-element event">
                            <div class="date-icon">
                                <figure class="day">04</figure>
                                <figure class="month">Jul</figure>
                            </div>
                            <h4><a href="detail.html">Donec mattis mi vitae volutpat</a></h4>
                            <figure class="date"><i class="icon_clock_alt"></i>12:00</figure>
                            <p>Nullam vitae ex ac neque viverra ullamcorper eu at nunc. Morbi imperdiet.</p>
                            <a href="detail.html" class="link arrow">More</a>
                        </div>
                        <!--end text-element-->
                    </div>
                    <!--end col-md-4-->
                    <div class="col-md-4 col-sm-4">
                        <div class="text-element event">
                            <div class="date-icon">
                                <figure class="day">12</figure>
                                <figure class="month">Aug</figure>
                            </div>
                            <h4><a href="detail.html">Vivamus placerat</a></h4>
                            <figure class="date"><i class="icon_clock_alt"></i>12:00</figure>
                            <p>Aenean sed purus ut massa scelerisque bibendum eget vel massa.</p>
                            <a href="detail.html" class="link arrow">More</a>
                        </div>
                        <!--end text-element-->
                    </div>
                    <!--end col-md-4-->
                </div>
                <!--end row-->
                <div class="background-wrapper">
                    <div class="background-color background-color-black opacity-5"></div>
                </div>
                <!--end background-wrapper-->
            </div>
            <!--end container-->
        </section>
        <!--end block-->

        {{-- <section class="block">
                <div class="container">
                    <div class="row">
                        <div class="col-md-9 col-sm-9">
                            <div class="section-title">
                                <h2>Recently Rated Items</h2>
                            </div>
                            <!--end section-title-->
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="item" data-id="2">
                                        <a href="detail.html">
                                            <div class="description">
                                                <div class="label label-default">Restaurant</div>
                                                <h3>Ironapple</h3>
                                                <h4>4209 Glenview Drive</h4>
                                            </div>
                                            <!--end description-->
                                            <div class="image bg-transfer">
                                                <img src="assets/img/items/2.jpg" alt="">
                                            </div>
                                            <!--end image-->
                                        </a>
                                        <div class="additional-info">
                                            <div class="rating-passive" data-rating="3">
                                                <span class="stars"></span>
                                                <span class="reviews">13</span>
                                            </div>
                                            <div class="controls-more">
                                                <ul>
                                                    <li><a href="#">Add to favorites</a></li>
                                                    <li><a href="#">Add to watchlist</a></li>
                                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                                </ul>
                                            </div>
                                            <!--end controls-more-->
                                        </div>
                                        <!--end additional-info-->
                                    </div>
                                    <!--end item-->
                                </div>
                                <!--<end col-md-4-->
                                <div class="col-md-5 col-sm-5">
                                    <div class="item" data-id="3">
                                        <figure class="ribbon">Top</figure>
                                        <a href="detail.html">
                                            <div class="description">
                                                <figure>Starts at: 19:00</figure>
                                                <div class="label label-default">Event</div>
                                                <h3>Food Festival</h3>
                                                <h4>840 My Drive</h4>
                                            </div>
                                            <!--end description-->
                                            <div class="image bg-transfer">
                                                <img src="assets/img/items/4.jpg" alt="">
                                            </div>
                                            <!--end image-->
                                        </a>
                                        <div class="additional-info">
                                            <figure class="circle" title="Featured"><i class="fa fa-check"></i></figure>
                                            <div class="rating-passive" data-rating="5">
                                                <span class="stars"></span>
                                                <span class="reviews">12</span>
                                            </div>
                                            <div class="controls-more">
                                                <ul>
                                                    <li><a href="#">Add to favorites</a></li>
                                                    <li><a href="#">Add to watchlist</a></li>
                                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                                </ul>
                                            </div>
                                            <!--end controls-more-->
                                        </div>
                                        <!--end additional-info-->
                                    </div>
                                    <!--end item-->
                                </div>
                                <!--<end col-md-5-->
                                <div class="col-md-3 col-sm-3">
                                    <div class="item" data-id="4">
                                        <a href="detail.html">
                                            <div class="description">
                                                <div class="label label-default">Lounge</div>
                                                <h3>Cosmopolit</h3>
                                                <h4>2896 Ripple Street</h4>
                                            </div>
                                            <!--end description-->
                                            <div class="image bg-transfer">
                                                <img src="assets/img/items/5.jpg" alt="">
                                            </div>
                                            <!--end image-->
                                        </a>
                                        <div class="additional-info">
                                            <div class="rating-passive" data-rating="5">
                                                <span class="stars"></span>
                                                <span class="reviews">43</span>
                                            </div>
                                            <div class="controls-more">
                                                <ul>
                                                    <li><a href="#">Add to favorites</a></li>
                                                    <li><a href="#">Add to watchlist</a></li>
                                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                                </ul>
                                            </div>
                                            <!--end controls-more-->
                                        </div>
                                        <!--end additional-info-->
                                    </div>
                                    <!--end item-->
                                </div>
                                <!--<end col-md-3-->
                            </div>
                            <!--end row-->
                        </div>
                        <!--end col-md-9-->
                        <div class="col-md-3 col-sm-3">
                            <div class="section-title">
                                <h2>Client’s Word</h2>
                            </div>
                            <div class="testimonials center box">
                                <div class="owl-carousel" data-owl-items="1" data-owl-nav="0" data-owl-dots="1">
                                    <blockquote>
                                        <div class="image">
                                            <div class="bg-transfer">
                                                <img src="assets/img/person-01.jpg" alt="">
                                            </div>
                                        </div>
                                        <h3>Jane Woodstock</h3>
                                        <h4>CEO at ArtBrands</h4>
                                        <p>Ut nec vulputate enim. Nulla faucibus convallis dui. Donec arcu enim, scelerisque
                                            gravida lacus vel.</p>
                                    </blockquote>
                                    <blockquote>
                                        <div class="image">
                                            <div class="bg-transfer">
                                                <img src="assets/img/person-04.jpg" alt="">
                                            </div>
                                        </div>
                                        <h3>Peter Doe</h3>
                                        <h4>CEO at ArtBrands</h4>
                                        <p>Donec arcu enim, scelerisque gravida lacus vel, dignissim cursus lectus. Aliquam
                                            laoreet purus in iaculis sodales.</p>
                                    </blockquote>
                                </div>
                            </div>
                        </div>
                        <!--end col-md-3-->
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->
            <section class="block">
                <div class="container">
                    <div class="section-title">
                        <h2>From the Blog</h2>
                    </div>
                    <!--end section-title-->
                    <div class="row">
                        <div class="col-md-4 col-sm-4">
                            <div class="text-element">
                                <h4><a href="blog-detail.html">Lorem ipsum dolor sit amet</a></h4>
                                <figure class="date">21.06.2015</figure>
                                <p>Ut nec vulputate enim. Nulla faucibus convallis dui. Donec arcu enim, scelerisque gravida
                                    lacus vel, dignissim cursus</p>
                                <a href="blog-detail.html"><i class="arrow_right"></i></a>
                            </div>
                            <!--end text-element-->
                        </div>
                        <!--end col-md-4-->
                        <div class="col-md-4 col-sm-4">
                            <div class="text-element">
                                <h4><a href="blog-detail.html">Sed et justo ut nibh condimentum lacinia</a></h4>
                                <figure class="date">13.06.2015</figure>
                                <p>Donec arcu enim, scelerisque gravida lacus vel, dignissim cursus lectus. Aliquam laoreet
                                    purus in iaculis sodales. </p>
                                <a href="blog-detail.html"><i class="arrow_right"></i></a>
                            </div>
                            <!--end text-element-->
                        </div>
                        <!--end col-md-4-->
                        <div class="col-md-4 col-sm-4">
                            <div class="text-element">
                                <h4><a href="blog-detail.html">Suspendisse varius eros id enim </a></h4>
                                <figure class="date">03.04.2015</figure>
                                <p>Nullam nec turpis blandit, sodales risus vitae, tincidunt velit. Vestibulum ac ipsum
                                    tincidunt, vestibulum leo eget, </p>
                                <a href="blog-detail.html"><i class="arrow_right"></i></a>
                            </div>
                            <!--end text-element-->
                        </div>
                        <!--end col-md-4-->
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->

            <div class="container">
                <hr>
            </div>
            <!--end container-->

            <section class="block">
                <div class="container">
                    <div class="center section-title opacity-40">
                        <h5>Partners</h5>
                    </div>
                    <div class="logos">
                        <div class="logo">
                            <a href="#"><img src="assets/img/logo-1.png" alt=""></a>
                        </div>
                        <div class="logo">
                            <a href="#"><img src="assets/img/logo-2.png" alt=""></a>
                        </div>
                        <div class="logo">
                            <a href="#"><img src="assets/img/logo-3.png" alt=""></a>
                        </div>
                        <div class="logo">
                            <a href="#"><img src="assets/img/logo-4.png" alt=""></a>
                        </div>
                        <div class="logo">
                            <a href="#"><img src="assets/img/logo-5.png" alt=""></a>
                        </div>
                    </div>
                    <!--/ .logos-->
                </div>
                <!--end container-->
            </section> --}}
        <!--end block-->
    @else
        <div class="hero-section full-screen has-map has-sidebar">
            <div class="map-wrapper">
                <div class="geo-location">
                    <i class="fa fa-map-marker"></i>
                </div>
                <div class="map" id="map-homepage"></div>
            </div>
            <!--end map-wrapper-->
            <div class="results-wrapper">
                <div class="form search-form inputs-underline">
                    <form>
                        <div class="section-title">
                            <h2>Search</h2>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="keyword" placeholder="Enter keyword">
                        </div>
                        <!--end form-group-->
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <select class="form-control selectpicker" name="city">
                                        <option value="">Location</option>
                                        <option value="1">New York</option>
                                        <option value="2">Washington</option>
                                        <option value="3">London</option>
                                        <option value="4">Paris</option>
                                    </select>
                                </div>
                                <!--end form-group-->
                            </div>
                            <!--end col-md-6-->
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <select class="form-control selectpicker" name="category">
                                        <option value="">Category</option>
                                        <option value="restaurant">Restaurant</option>
                                        <option value="car rental">Car Rental</option>
                                        <option value="relax">Relax</option>
                                        <option value="sport">Sport</option>
                                        <option value="wellness">Wellness</option>
                                    </select>
                                </div>
                                <!--end form-group-->
                            </div>
                            <!--end col-md-6-->
                        </div>
                        <!--end row-->
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" class="form-control date-picker" name="min-price"
                                        placeholder="Event Date" data-date-format="MM/DD/YYYY/HH:mm">
                                </div>
                                <!--end form-group-->
                            </div>
                            <!--end col-md-6-->
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <div class="ui-slider" id="price-slider" data-value-min="10" data-value-max="400"
                                        data-value-type="price" data-currency="$" data-currency-placement="before">
                                        <div class="values clearfix">
                                            <input class="value-min" name="value-min[]" readonly>
                                            <input class="value-max" name="value-max[]" readonly>
                                        </div>
                                        <div class="element"></div>
                                    </div>
                                    <!--end price-slider-->
                                </div>
                            </div>
                            <!--end col-md-6-->
                        </div>
                        <!--end row-->
                        <div class="form-group">
                            <button type="submit" data-ajax-response="map"
                                data-ajax-data-file="assets/external/data_2.php" data-ajax-auto-zoom="1"
                                class="btn btn-primary pull-right"><i class="fa fa-search"></i></button>
                        </div>
                        <!--end form-group-->
                    </form>
                    <!--end form-hero-->
                </div>
                <div class="results">
                    <div class="tse-scrollable">
                        <div class="tse-content">
                            <div class="section-title">
                                <h2>Search Results<span class="results-number"></span></h2>
                            </div>
                            <!--end section-title-->
                            <div class="results-content"></div>
                            <!--end results-content-->
                        </div>
                        <!--end tse-content-->
                    </div>
                    <!--end tse-scrollable-->
                </div>
                <!--end results-->
            </div>
            <!--end results-wrapper-->
        </div>
    @endif
    <!--end hero-section-->
    @if (false)
        <div class="block">
            <div class="container">
                <div class="center">
                    <div class="section-title">
                        <div class="center">
                            <h2>Recent Places</h2>
                            <h3 class="subtitle">Fusce eu mollis dui, varius convallis mauris. Nam dictum id</h3>
                        </div>
                    </div>
                    <!--end section-title-->
                </div>
                <!--end center-->
                <div class="row">
                    <div class="col-md-3 col-sm-3">
                        <div class="item" data-id="1">
                            <a href="detail.html">
                                <div class="description">
                                    <figure>Average Price: $8 - $30</figure>
                                    <div class="label label-default">Restaurant</div>
                                    <h3>Marky’s Restaurant</h3>
                                    <h4>63 Birch Street</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/1.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="4">
                                    <span class="stars"></span>
                                    <span class="reviews">6</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                    </div>
                    <!--<end col-md-3-->
                    <div class="col-md-3 col-sm-3">
                        <div class="item" data-id="2">
                            <figure class="circle featured sale">-25%</figure>
                            <a href="detail.html">
                                <div class="description">
                                    <div class="label label-default">Restaurant</div>
                                    <h3>Ironapple</h3>
                                    <h4>4209 Glenview Drive</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/2.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="3">
                                    <span class="stars"></span>
                                    <span class="reviews">13</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                    </div>
                    <!--<end col-md-3-->
                    <div class="col-md-6 col-sm-6">
                        <div class="item" data-id="15">
                            <figure class="ribbon">Top</figure>
                            <a href="detail.html">
                                <div class="description">
                                    <figure>Happy hour: 18:00 - 19:00</figure>
                                    <div class="label label-default">Bar & Grill</div>
                                    <h3>Bambi Planet Houseboat Bar& Grill </h3>
                                    <h4>3857 Losh Lane</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/3.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <figure class="circle" title="Featured"><i class="fa fa-check"></i></figure>
                                <div class="rating-passive" data-rating="5">
                                    <span class="stars"></span>
                                    <span class="reviews">56</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                    </div>
                    <!--<end col-md-3-->
                    <div class="col-md-4 col-sm-4">
                        <div class="item" data-id="3">
                            <figure class="ribbon">Top</figure>
                            <a href="detail.html">
                                <div class="description">
                                    <figure>Starts at: 19:00</figure>
                                    <div class="label label-default">Event</div>
                                    <h3>Food Festival</h3>
                                    <h4>840 My Drive</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/4.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <figure class="circle" title="Featured"><i class="fa fa-check"></i></figure>
                                <div class="rating-passive" data-rating="5">
                                    <span class="stars"></span>
                                    <span class="reviews">12</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                    </div>
                    <!--<end col-md-4-->
                    <div class="col-md-3 col-sm-3">
                        <div class="item" data-id="4">
                            <a href="detail.html">
                                <div class="description">
                                    <div class="label label-default">Lounge</div>
                                    <h3>Cosmopolit</h3>
                                    <h4>2896 Ripple Street</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/5.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="5">
                                    <span class="stars"></span>
                                    <span class="reviews">43</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                    </div>
                    <!--<end col-md-3-->
                    <div class="col-md-5 col-sm-5">
                        <div class="item" data-id="6">
                            <a href="detail.html">
                                <div class="description">
                                    <figure>Free entry</figure>
                                    <div class="label label-default">Concert</div>
                                    <h3>Stand Up Show</h3>
                                    <h4>371 Kinney Street</h4>
                                </div>
                                <!--end description-->
                                <div class="image bg-transfer">
                                    <img src="assets/img/items/6.jpg" alt="">
                                </div>
                                <!--end image-->
                            </a>
                            <div class="additional-info">
                                <div class="rating-passive" data-rating="0">
                                    <span class="stars"></span>
                                    <span class="reviews">0</span>
                                </div>
                                <div class="controls-more">
                                    <ul>
                                        <li><a href="#">Add to favorites</a></li>
                                        <li><a href="#">Add to watchlist</a></li>
                                        <li><a href="#" class="quick-detail">Quick detail</a></li>
                                    </ul>
                                </div>
                                <!--end controls-more-->
                            </div>
                            <!--end additional-info-->
                        </div>
                        <!--end item-->
                    </div>
                    <!--<end col-md-3-->
                </div>
                <!--end row-->
                <div class="center">
                    <a href="listing.html" class="btn btn-primary btn-light-frame btn-rounded btn-framed arrow">View all
                        listings</a>
                </div>
                <!--end center-->
            </div>
            <!--end container-->
        </div>
        <!--end block-->
        <div class="container">
            <hr>
        </div>
        <div class="block">
            <div class="container">
                <div class="section-title">
                    <div class="center">
                        <h2>Browse Our Listings</h2>
                    </div>
                </div>
                <!--end section-title-->
                <div class="categories-list">
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                            <div class="list-item">
                                <div class="title">
                                    <div class="icon"><i class="fa fa-paint-brush"></i></div>
                                    <h3><a href="#">Arts & Humanities</a></h3>
                                </div>
                                <!--end title-->
                                <ul>
                                    <li><a href="">Photography</a>
                                        <figure class="count">3</figure>
                                    </li>
                                    <li><a href="">History</a>
                                        <figure class="count">2</figure>
                                    </li>
                                    <li><a href="">Literature</a>
                                        <figure class="count">4</figure>
                                    </li>
                                </ul>
                            </div>
                            <!--end list-item-->
                        </div>
                        <!--end col-md-3-->
                        <div class="col-md-3 col-sm-3">
                            <div class="list-item">
                                <div class="title">
                                    <div class="icon"><i class="fa fa-suitcase"></i></div>
                                    <h3><a href="#">Business & Economy</a></h3>
                                </div>
                                <!--end title-->
                                <ul>
                                    <li><a href="">Business to Business</a>
                                        <figure class="count">6</figure>
                                    </li>
                                    <li><a href="">Finance</a>
                                        <figure class="count">4</figure>
                                    </li>
                                    <li><a href="">Shopping</a>
                                        <figure class="count">3</figure>
                                    </li>
                                    <li><a href="">Jobs</a>
                                        <figure class="count">5</figure>
                                    </li>
                                </ul>
                            </div>
                            <!--end list-item-->
                        </div>
                        <!--end col-md-3-->
                        <div class="col-md-3 col-sm-3">
                            <div class="list-item">
                                <div class="title">
                                    <div class="icon"><i class="fa fa-desktop"></i></div>
                                    <h3><a href="#">Computer & Internet</a></h3>
                                </div>
                                <!--end title-->
                                <ul>
                                    <li><a href="">Hardware</a>
                                        <figure class="count">10</figure>
                                    </li>
                                    <li><a href="">Software</a>
                                        <figure class="count">4</figure>
                                    </li>
                                    <li><a href="">Websites</a>
                                        <figure class="count">6</figure>
                                    </li>
                                    <li><a href="">Games</a>
                                        <figure class="count">7</figure>
                                    </li>
                                </ul>
                            </div>
                            <!--end list-item-->
                        </div>
                        <!--end col-md-3-->
                        <div class="col-md-3 col-sm-3">
                            <div class="list-item">
                                <div class="title">
                                    <div class="icon"><i class="fa fa-graduation-cap"></i></div>
                                    <h3><a href="#">Education</a></h3>
                                </div>
                                <!--end title-->
                                <ul>
                                    <li><a href="">Colleges</a>
                                        <figure class="count">8</figure>
                                    </li>
                                    <li><a href="">K-12</a>
                                        <figure class="count">7</figure>
                                    </li>
                                    <li><a href="">Distance Learning </a>
                                        <figure class="count">2</figure>
                                    </li>
                                </ul>
                            </div>
                            <!--end list-item-->
                        </div>
                        <!--end col-md-3-->
                    </div>
                    <!--end row-->
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                            <div class="list-item">
                                <div class="title">
                                    <div class="icon"><i class="fa fa-television"></i></div>
                                    <h3><a href="#">Entertainment</a></h3>
                                </div>
                                <!--end title-->
                                <ul>
                                    <li><a href="">Movies</a>
                                        <figure class="count">6</figure>
                                    </li>
                                    <li><a href="">TV Shows</a>
                                        <figure class="count">9</figure>
                                    </li>
                                    <li><a href="">Music</a>
                                        <figure class="count">1</figure>
                                    </li>
                                    <li><a href="">Humor </a>
                                        <figure class="count">4</figure>
                                    </li>
                                </ul>
                            </div>
                            <!--end list-item-->
                        </div>
                        <!--end col-md-3-->
                        <div class="col-md-3 col-sm-3">
                            <div class="list-item">
                                <div class="title">
                                    <div class="icon"><i class="fa fa-university"></i></div>
                                    <h3><a href="#">Government</a></h3>
                                </div>
                                <!--end title-->
                                <ul>
                                    <li><a href="">Elections</a>
                                        <figure class="count">3</figure>
                                    </li>
                                    <li><a href="">Military</a>
                                        <figure class="count">2</figure>
                                    </li>
                                    <li><a href="">Law</a>
                                        <figure class="count">6</figure>
                                    </li>
                                    <li><a href="">Taxes</a>
                                        <figure class="count">7</figure>
                                    </li>
                                </ul>
                            </div>
                            <!--end list-item-->
                        </div>
                        <!--end col-md-3-->
                        <div class="col-md-3 col-sm-3">
                            <div class="list-item">
                                <div class="title">
                                    <div class="icon"><i class="fa fa-heart"></i></div>
                                    <h3><a href="#">Health</a></h3>
                                </div>
                                <!--end title-->
                                <ul>
                                    <li><a href="">Disease</a>
                                        <figure class="count">1</figure>
                                    </li>
                                    <li><a href="">Drugs</a>
                                        <figure class="count">5</figure>
                                    </li>
                                    <li><a href="">Fitness</a>
                                        <figure class="count">4</figure>
                                    </li>
                                    <li><a href="">Nutrition </a>
                                        <figure class="count">8</figure>
                                    </li>
                                </ul>
                            </div>
                            <!--end list-item-->
                        </div>
                        <!--end col-md-3-->
                        <div class="col-md-3 col-sm-3">
                            <div class="list-item">
                                <div class="title">
                                    <div class="icon"><i class="fa fa-newspaper-o"></i></div>
                                    <h3><a href="#">News & Media</a></h3>
                                </div>
                                <!--end title-->
                                <ul>
                                    <li><a href="">Newspapers</a>
                                        <figure class="count">5</figure>
                                    </li>
                                    <li><a href="">Radio</a>
                                        <figure class="count">9</figure>
                                    </li>
                                    <li><a href="">Weather</a>
                                        <figure class="count">3</figure>
                                    </li>
                                    <li><a href="">Blogs</a>
                                        <figure class="count">4</figure>
                                    </li>
                                </ul>
                            </div>
                            <!--end list-item-->
                        </div>
                        <!--end col-md-3-->
                    </div>
                    <!--end row-->
                </div>
                <!--end categories-list-->
            </div>
            <!--end container-->
        </div>
        <!--end block-->
        <div class="block big-padding">
            <div class="container">
                <div class="vertical-aligned-elements">
                    <div class="element width-50">
                        <h3>Subscribe and be notified about new locations</h3>
                    </div>
                    <!--end element-->
                    <div class="element width-50">
                        <form class="form form-email inputs-underline" id="form-subscribe">
                            <div class="input-group">
                                <input type="text" class="form-control" name="email" placeholder="Your email"
                                    required="">
                                <span class="input-group-btn">
                                    <button class="btn" type="submit"><i class="arrow_right"></i></button>
                                </span>
                            </div><!-- /input-group -->
                        </form>
                        <!--end form-->
                    </div>
                    <!--end element-->
                </div>
                <!--end vertical-aligned-elements-->
            </div>
            <!--end container-->
            <div class="background-wrapper">
                <div class="background-color background-color-black opacity-5"></div>
            </div>
            <!--end background-wrapper-->
        </div>
        <!--end block-->
        <div class="block background-is-dark">
            <div class="container">
                <div class="section-title vertical-aligned-elements">
                    <div class="element">
                        <h2>Promoted Locations</h2>
                    </div>
                    <div class="element text-align-right">
                        <a href="#" class="btn btn-framed btn-rounded btn-default invisible-on-mobile">Promote
                            yours</a>
                        <div id="gallery-nav"></div>
                    </div>
                </div>
                <!--end section-title-->
            </div>
            <div class="gallery featured">
                <div class="owl-carousel" data-owl-items="6" data-owl-loop="1" data-owl-auto-width="1" data-owl-nav="1"
                    data-owl-dots="1" data-owl-nav-container="#gallery-nav">
                    <div class="item featured" data-id="1">
                        <a href="detail.html">
                            <div class="description">
                                <figure>Average Price: $8 - $30</figure>
                                <div class="label label-default">Restaurant</div>
                                <h3>Marky’s Restaurant</h3>
                                <h4>63 Birch Street</h4>
                            </div>
                            <!--end description-->
                            <div class="image bg-transfer">
                                <img src="assets/img/items/1.jpg" alt="">
                            </div>
                            <!--end image-->
                        </a>
                        <div class="additional-info">
                            <div class="rating-passive" data-rating="4">
                                <span class="stars"></span>
                                <span class="reviews">6</span>
                            </div>
                            <div class="controls-more">
                                <ul>
                                    <li><a href="#">Add to favorites</a></li>
                                    <li><a href="#">Add to watchlist</a></li>
                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                </ul>
                            </div>
                            <!--end controls-more-->
                        </div>
                        <!--end additional-info-->
                    </div>
                    <!--end item-->
                    <div class="item featured" data-id="23">
                        <a href="detail.html">
                            <div class="description">
                                <figure>Starts from: $14.99</figure>
                                <div class="label label-default">Trip</div>
                                <h3>Nascar Racing</h3>
                                <h4>london Airport</h4>
                            </div>
                            <!--end description-->
                            <div class="image bg-transfer">
                                <img src="assets/img/items/11.jpg" alt="">
                            </div>
                            <!--end image-->
                        </a>
                        <div class="additional-info">
                            <div class="rating-passive" data-rating="4">
                                <span class="stars"></span>
                                <span class="reviews">6</span>
                            </div>
                            <div class="controls-more">
                                <ul>
                                    <li><a href="#">Add to favorites</a></li>
                                    <li><a href="#">Add to watchlist</a></li>
                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                </ul>
                            </div>
                            <!--end controls-more-->
                        </div>
                        <!--end additional-info-->
                    </div>
                    <!--end item-->
                    <div class="item featured" data-id="3">
                        <a href="detail.html">
                            <div class="description">
                                <figure>
                                    <span><i class="fa fa-calendar"></i>12.08.2016</span>
                                    <span><i class="fa fa-clock-o"></i>08:00</span>
                                </figure>
                                <div class="label label-default">Event</div>
                                <h3>Food Festival</h3>
                                <h4>63 Birch Street</h4>
                            </div>
                            <!--end description-->
                            <div class="image bg-transfer">
                                <img src="assets/img/items/4.jpg" alt="">
                            </div>
                            <!--end image-->
                        </a>
                        <div class="additional-info">
                            <div class="rating-passive" data-rating="4">
                                <span class="stars"></span>
                                <span class="reviews">6</span>
                            </div>
                            <div class="controls-more">
                                <ul>
                                    <li><a href="#">Add to favorites</a></li>
                                    <li><a href="#">Add to watchlist</a></li>
                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                </ul>
                            </div>
                            <!--end controls-more-->
                        </div>
                        <!--end additional-info-->
                    </div>
                    <!--end item-->
                    <div class="item featured" data-id="4">
                        <a href="detail.html">
                            <div class="description">
                                <figure>Average Price: $8 - $30</figure>
                                <div class="label label-default">Lounge</div>
                                <h3>Cosmopolit</h3>
                                <h4>4696 Jim Rosa Lane</h4>
                            </div>
                            <!--end description-->
                            <div class="image bg-transfer">
                                <img src="assets/img/items/5.jpg" alt="">
                            </div>
                            <!--end image-->
                        </a>
                        <div class="additional-info">
                            <div class="rating-passive" data-rating="4">
                                <span class="stars"></span>
                                <span class="reviews">6</span>
                            </div>
                            <div class="controls-more">
                                <ul>
                                    <li><a href="#">Add to favorites</a></li>
                                    <li><a href="#">Add to watchlist</a></li>
                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                </ul>
                            </div>
                            <!--end controls-more-->
                        </div>
                        <!--end additional-info-->
                    </div>
                    <!--end item-->
                    <div class="item featured" data-id="6">
                        <a href="detail.html">
                            <div class="description">
                                <div class="label label-default">Event</div>
                                <h3>Stand Up Show</h3>
                                <h4>63 Birch Street</h4>
                            </div>
                            <!--end description-->
                            <div class="image bg-transfer">
                                <img src="assets/img/items/6.jpg" alt="">
                            </div>
                            <!--end image-->
                        </a>
                        <div class="additional-info">
                            <div class="rating-passive" data-rating="4">
                                <span class="stars"></span>
                                <span class="reviews">6</span>
                            </div>
                            <div class="controls-more">
                                <ul>
                                    <li><a href="#">Add to favorites</a></li>
                                    <li><a href="#">Add to watchlist</a></li>
                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                </ul>
                            </div>
                            <!--end controls-more-->
                        </div>
                        <!--end additional-info-->
                    </div>
                    <!--end item-->
                    <div class="item featured" data-id="8">
                        <a href="detail.html">
                            <div class="description">
                                <figure>Get to know yor town!</figure>
                                <div class="label label-default">Event</div>
                                <h3>City Tour</h3>
                                <h4>63 Birch Street</h4>
                            </div>
                            <!--end description-->
                            <div class="image bg-transfer">
                                <img src="assets/img/items/10.jpg" alt="">
                            </div>
                            <!--end image-->
                        </a>
                        <div class="additional-info">
                            <div class="rating-passive" data-rating="4">
                                <span class="stars"></span>
                                <span class="reviews">6</span>
                            </div>
                            <div class="controls-more">
                                <ul>
                                    <li><a href="#">Add to favorites</a></li>
                                    <li><a href="#">Add to watchlist</a></li>
                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                </ul>
                            </div>
                            <!--end controls-more-->
                        </div>
                        <!--end additional-info-->
                    </div>
                    <!--end item-->
                    <div class="item featured" data-id="5">
                        <a href="detail.html">
                            <div class="description">
                                <div class="label label-default">Real Estate</div>
                                <h3>Beautiful Luxury Villa</h3>
                                <h4>59 Water Street</h4>
                            </div>
                            <!--end description-->
                            <div class="image bg-transfer">
                                <img src="assets/img/items/28.jpg" alt="">
                            </div>
                            <!--end image-->
                        </a>
                        <div class="additional-info">
                            <div class="rating-passive" data-rating="3">
                                <span class="stars"></span>
                                <span class="reviews">12</span>
                            </div>
                            <div class="controls-more">
                                <ul>
                                    <li><a href="#">Add to favorites</a></li>
                                    <li><a href="#">Add to watchlist</a></li>
                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                </ul>
                            </div>
                            <!--end controls-more-->
                        </div>
                        <!--end additional-info-->
                    </div>
                    <!--end item-->
                    <div class="item featured" data-id="7">
                        <a href="detail.html">
                            <div class="description">
                                <figure>Average Price: $8 - $30</figure>
                                <div class="label label-default">Bar</div>
                                <h3>Fiesta Bar</h3>
                                <h4>3524 Bryan Avenue</h4>
                            </div>
                            <!--end description-->
                            <div class="image bg-transfer">
                                <img src="assets/img/items/12.jpg" alt="">
                            </div>
                            <!--end image-->
                        </a>
                        <div class="additional-info">
                            <div class="rating-passive" data-rating="5">
                                <span class="stars"></span>
                                <span class="reviews">17</span>
                            </div>
                            <div class="controls-more">
                                <ul>
                                    <li><a href="#">Add to favorites</a></li>
                                    <li><a href="#">Add to watchlist</a></li>
                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                </ul>
                            </div>
                            <!--end controls-more-->
                        </div>
                        <!--end additional-info-->
                    </div>
                    <!--end item-->
                    <div class="item featured" data-id="1">
                        <a href="detail.html">
                            <div class="description">
                                <div class="label label-default">Adrenaline</div>
                                <h3>Senior C# Developer</h3>
                                <h4>ERF Solutions</h4>
                            </div>
                            <!--end description-->
                            <div class="image bg-transfer">
                                <img src="assets/img/items/16.jpg" alt="">
                            </div>
                            <!--end image-->
                        </a>
                        <div class="additional-info">
                            <div class="rating-passive" data-rating="4">
                                <span class="stars"></span>
                                <span class="reviews">6</span>
                            </div>
                            <div class="controls-more">
                                <ul>
                                    <li><a href="#">Add to favorites</a></li>
                                    <li><a href="#">Add to watchlist</a></li>
                                    <li><a href="#" class="quick-detail">Quick detail</a></li>
                                </ul>
                            </div>
                            <!--end controls-more-->
                        </div>
                        <!--end additional-info-->
                    </div>
                    <!--end item-->
                </div>
            </div>
            <!--end gallery-->
            <div class="background-wrapper">
                <div class="background-color background-color-default"></div>
            </div>
            <!--end background-wrapper-->
        </div>
        <!--end block-->

        <div class="block">
            <div class="container">
                <div class="section-title">
                    <h2>Events Near You</h2>
                </div>
                <!--end section-title-->
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                        <div class="text-element event">
                            <div class="date-icon">
                                <figure class="day">22</figure>
                                <figure class="month">Jun</figure>
                            </div>
                            <h4><a href="detail.html">Lorem ipsum dolor sit amet</a></h4>
                            <figure class="date"><i class="icon_clock_alt"></i>08:00</figure>
                            <p>Ut nec vulputate enim. Nulla faucibus convallis dui. Donec arcu enim, scelerisque.</p>
                            <a href="detail.html" class="link arrow">More</a>
                        </div>
                        <!--end text-element-->
                    </div>
                    <!--end col-md-4-->
                    <div class="col-md-4 col-sm-4">
                        <div class="text-element event">
                            <div class="date-icon">
                                <figure class="day">04</figure>
                                <figure class="month">Jul</figure>
                            </div>
                            <h4><a href="detail.html">Donec mattis mi vitae volutpat</a></h4>
                            <figure class="date"><i class="icon_clock_alt"></i>12:00</figure>
                            <p>Nullam vitae ex ac neque viverra ullamcorper eu at nunc. Morbi imperdiet.</p>
                            <a href="detail.html" class="link arrow">More</a>
                        </div>
                        <!--end text-element-->
                    </div>
                    <!--end col-md-4-->
                    <div class="col-md-4 col-sm-4">
                        <div class="text-element event">
                            <div class="date-icon">
                                <figure class="day">12</figure>
                                <figure class="month">Aug</figure>
                            </div>
                            <h4><a href="detail.html">Vivamus placerat</a></h4>
                            <figure class="date"><i class="icon_clock_alt"></i>12:00</figure>
                            <p>Aenean sed purus ut massa scelerisque bibendum eget vel massa.</p>
                            <a href="detail.html" class="link arrow">More</a>
                        </div>
                        <!--end text-element-->
                    </div>
                    <!--end col-md-4-->
                </div>
                <!--end row-->
                <div class="background-wrapper">
                    <div class="background-color background-color-black opacity-5"></div>
                </div>
                <!--end background-wrapper-->
            </div>
            <!--end container-->
        </div>
        <!--end block-->

        <div class="block">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-9">
                        <div class="section-title">
                            <h2>Recently Rated Items</h2>
                        </div>
                        <!--end section-title-->
                        <div class="row">
                            <div class="col-md-4 col-sm-4">
                                <div class="item" data-id="2">
                                    <figure class="circle featured sale">-12%</figure>
                                    <a href="detail.html">
                                        <div class="description">
                                            <div class="label label-default">Restaurant</div>
                                            <h3>Ironapple</h3>
                                            <h4>4209 Glenview Drive</h4>
                                        </div>
                                        <!--end description-->
                                        <div class="image bg-transfer">
                                            <img src="assets/img/items/2.jpg" alt="">
                                        </div>
                                        <!--end image-->
                                    </a>
                                    <div class="additional-info">
                                        <div class="rating-passive" data-rating="3">
                                            <span class="stars"></span>
                                            <span class="reviews">13</span>
                                        </div>
                                        <div class="controls-more">
                                            <ul>
                                                <li><a href="#">Add to favorites</a></li>
                                                <li><a href="#">Add to watchlist</a></li>
                                                <li><a href="#" class="quick-detail">Quick detail</a></li>
                                            </ul>
                                        </div>
                                        <!--end controls-more-->
                                    </div>
                                    <!--end additional-info-->
                                </div>
                                <!--end item-->
                            </div>
                            <!--<end col-md-4-->
                            <div class="col-md-5 col-sm-5">
                                <div class="item" data-id="3">
                                    <figure class="ribbon">Top</figure>
                                    <a href="detail.html">
                                        <div class="description">
                                            <figure>Starts at: 19:00</figure>
                                            <div class="label label-default">Event</div>
                                            <h3>Food Festival</h3>
                                            <h4>840 My Drive</h4>
                                        </div>
                                        <!--end description-->
                                        <div class="image bg-transfer">
                                            <img src="assets/img/items/4.jpg" alt="">
                                        </div>
                                        <!--end image-->
                                    </a>
                                    <div class="additional-info">
                                        <figure class="circle" title="Featured"><i class="fa fa-check"></i></figure>
                                        <div class="rating-passive" data-rating="5">
                                            <span class="stars"></span>
                                            <span class="reviews">12</span>
                                        </div>
                                        <div class="controls-more">
                                            <ul>
                                                <li><a href="#">Add to favorites</a></li>
                                                <li><a href="#">Add to watchlist</a></li>
                                                <li><a href="#" class="quick-detail">Quick detail</a></li>
                                            </ul>
                                        </div>
                                        <!--end controls-more-->
                                    </div>
                                    <!--end additional-info-->
                                </div>
                                <!--end item-->
                            </div>
                            <!--<end col-md-5-->
                            <div class="col-md-3 col-sm-3">
                                <div class="item" data-id="4">
                                    <a href="detail.html">
                                        <div class="description">
                                            <div class="label label-default">Lounge</div>
                                            <h3>Cosmopolit</h3>
                                            <h4>2896 Ripple Street</h4>
                                        </div>
                                        <!--end description-->
                                        <div class="image bg-transfer">
                                            <img src="assets/img/items/5.jpg" alt="">
                                        </div>
                                        <!--end image-->
                                    </a>
                                    <div class="additional-info">
                                        <div class="rating-passive" data-rating="5">
                                            <span class="stars"></span>
                                            <span class="reviews">43</span>
                                        </div>
                                        <div class="controls-more">
                                            <ul>
                                                <li><a href="#">Add to favorites</a></li>
                                                <li><a href="#">Add to watchlist</a></li>
                                                <li><a href="#" class="quick-detail">Quick detail</a></li>
                                            </ul>
                                        </div>
                                        <!--end controls-more-->
                                    </div>
                                    <!--end additional-info-->
                                </div>
                                <!--end item-->
                            </div>
                            <!--<end col-md-3-->
                        </div>
                        <!--end row-->
                    </div>
                    <!--end col-md-9-->
                    <div class="col-md-3 col-sm-3">
                        <div class="section-title">
                            <h2>Client’s Word</h2>
                        </div>
                        <div class="testimonials center box">
                            <div class="owl-carousel" data-owl-items="1" data-owl-nav="0" data-owl-dots="1">
                                <blockquote>
                                    <div class="image">
                                        <div class="bg-transfer">
                                            <img src="assets/img/person-01.jpg" alt="">
                                        </div>
                                    </div>
                                    <h3>Jane Woodstock</h3>
                                    <h4>CEO at ArtBrands</h4>
                                    <p>Ut nec vulputate enim. Nulla faucibus convallis dui. Donec arcu enim, scelerisque
                                        gravida
                                        lacus vel.</p>
                                </blockquote>
                                <blockquote>
                                    <div class="image">
                                        <div class="bg-transfer">
                                            <img src="assets/img/person-04.jpg" alt="">
                                        </div>
                                    </div>
                                    <h3>Peter Doe</h3>
                                    <h4>CEO at ArtBrands</h4>
                                    <p>Donec arcu enim, scelerisque gravida lacus vel, dignissim cursus lectus. Aliquam
                                        laoreet
                                        purus in iaculis sodales.</p>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <!--end col-md-3-->
                </div>
                <!--end row-->
            </div>
            <!--end container-->
        </div>
        <!--end block-->
        <div class="block">
            <div class="container">
                <div class="section-title">
                    <h2>From the Blog</h2>
                </div>
                <!--end section-title-->
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                        <div class="text-element">
                            <h4><a href="blog-detail.html">Lorem ipsum dolor sit amet</a></h4>
                            <figure class="date">21.06.2015</figure>
                            <p>Ut nec vulputate enim. Nulla faucibus convallis dui. Donec arcu enim, scelerisque gravida
                                lacus
                                vel, dignissim cursus</p>
                            <a href="blog-detail.html"><i class="arrow_right"></i></a>
                        </div>
                        <!--end text-element-->
                    </div>
                    <!--end col-md-4-->
                    <div class="col-md-4 col-sm-4">
                        <div class="text-element">
                            <h4><a href="blog-detail.html">Sed et justo ut nibh condimentum lacinia</a></h4>
                            <figure class="date">13.06.2015</figure>
                            <p>Donec arcu enim, scelerisque gravida lacus vel, dignissim cursus lectus. Aliquam laoreet
                                purus in
                                iaculis sodales. </p>
                            <a href="blog-detail.html"><i class="arrow_right"></i></a>
                        </div>
                        <!--end text-element-->
                    </div>
                    <!--end col-md-4-->
                    <div class="col-md-4 col-sm-4">
                        <div class="text-element">
                            <h4><a href="blog-detail.html">Suspendisse varius eros id enim </a></h4>
                            <figure class="date">03.04.2015</figure>
                            <p>Nullam nec turpis blandit, sodales risus vitae, tincidunt velit. Vestibulum ac ipsum
                                tincidunt,
                                vestibulum leo eget, </p>
                            <a href="blog-detail.html"><i class="arrow_right"></i></a>
                        </div>
                        <!--end text-element-->
                    </div>
                    <!--end col-md-4-->
                </div>
                <!--end row-->
            </div>
            <!--end container-->
        </div>
        <!--end block-->

        <div class="container">
            <hr>
        </div>
        <!--end container-->

        <div class="block">
            <div class="container">
                <div class="logos">
                    <div class="logo">
                        <a href="#"><img src="assets/img/logo-1.png" alt=""></a>
                    </div>
                    <div class="logo">
                        <a href="#"><img src="assets/img/logo-2.png" alt=""></a>
                    </div>
                    <div class="logo">
                        <a href="#"><img src="assets/img/logo-3.png" alt=""></a>
                    </div>
                    <div class="logo">
                        <a href="#"><img src="assets/img/logo-4.png" alt=""></a>
                    </div>
                    <div class="logo">
                        <a href="#"><img src="assets/img/logo-5.png" alt=""></a>
                    </div>
                </div>
                <!--/ .logos-->
            </div>
            <!--end container-->
        </div>
    @endif
@endsection

@section('script')
    <script>
        var optimizedDatabaseLoading = 0;
        var _latitude = 40.7344458;
        var _longitude = -73.86704922;
        var element = "map-homepage";
        var markerTarget = "sidebar"; // use "sidebar", "infobox" or "modal" - defines the action after click on marker
        var sidebarResultTarget =
        "sidebar"; // use "sidebar", "modal" or "new_page" - defines the action after click on marker
        var showMarkerLabels = false; // next to every marker will be a bubble with title
        var mapDefaultZoom = 14; // default zoom
        heroMap(_latitude, _longitude, element, markerTarget, sidebarResultTarget, showMarkerLabels, mapDefaultZoom);
    </script>
@endsection
