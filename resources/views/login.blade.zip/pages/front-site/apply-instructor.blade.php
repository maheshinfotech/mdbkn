@extends('layouts.front-site.frontend')

@section('front-body')
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li><a href="#">Pages</a></li>
            <li class="active">Contact</li>
        </ol>
        <!--end breadcrumb-->
        <div class="row">
            <div class="col-md-4 col-sm-4 col-md-offset-4 col-sm-offset-4">
                <section class="page-title">
                    <h1>Register</h1>
                </section <!--end page-title-->
                <section>
                    <form class="form inputs-underline">
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label for="first_name">First Name</label>
                                    <input type="text" class="form-control" name="first_name" id="first_name"
                                        placeholder="First name">
                                </div>
                                <!--end form-group-->
                            </div>
                            <!--end col-md-6-->
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label for="last_name">Last Name</label>
                                    <input type="text" class="form-control" name="last_name" id="last_name"
                                        placeholder="Last name">
                                </div>
                                <!--end form-group-->
                            </div>
                            <!--end col-md-6-->
                        </div>
                        <!--enr row-->
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                        </div>
                        <!--end form-group-->
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" id="password"
                                placeholder="Password">
                        </div>
                        <!--end form-group-->
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" class="form-control" name="confirm_password" id="confirm_password"
                                placeholder="Confirm Password">
                        </div>
                        <!--end form-group-->
                        <div class="form-group center">
                            <button type="submit" class="btn btn-primary width-100">Register as Instructor</button>
                        </div>
                        <!--end form-group-->
                    </form>
                    
                    <p class="center">If you want to login , Please <a
                            href="{{url(config('app.front_prefix').'login-instructor')}}">Click Here</a></p>
                    
                    <hr>
                    <p class="center">By clicking on “Register Now” button you are accepting the <a
                            href="terms-conditions.html">Terms & Conditions</a></p>

                </section>
            </div>
            <!--col-md-4-->
        </div>
        <!--end ro-->
    </div>
@endsection
