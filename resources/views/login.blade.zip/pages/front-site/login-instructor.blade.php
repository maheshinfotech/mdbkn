@extends('layouts.front-site.frontend')

@section('front-body')
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li><a href="#">Pages</a></li>
            <li class="active">Login</li>
        </ol>
        <!--end breadcrumb-->
        <div class="row">
            <div class="col-md-4 col-sm-4 col-md-offset-4 col-sm-offset-4">
                <section class="page-title">
                    <h1>Login</h1>
                </section >
                <section>
                    <form class="form inputs-underline">
                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <label for="first_name">Email*</label>
                                    <input type="text" class="form-control" name="first_name" id="first_name"
                                        placeholder="Email">
                                </div>
                                <!--end form-group-->
                            </div>
                        </div>
                        <div class="row">
                            <!--end col-md-6-->
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <label for="last_name">Password*</label>
                                    <input type="text" class="form-control" name="last_name" id="last_name"
                                        placeholder="Password">
                                </div>
                                <!--end form-group-->
                            </div>
                        
                            <!--end col-md-6-->
                        </div>
                        <!--enr row-->

                        <!--end form-group-->
                        <div class="form-group center">
                            <button type="submit" class="btn btn-primary width-100">Login</button>
                        </div>
                        <!--end form-group-->
                    </form>
                    
                    <p class="center">If you forgot your password , Please <a
                            href="{{url(config('app.front_prefix').'forgot-instructor')}}">Click Here</a></p>
                    
                    <hr>
                    <p class="center">By clicking on “Register Now” button you are accepting the <a
                            href="terms-conditions.html">Terms & Conditions</a></p>

                </section>
            </div>
            <!--col-md-4-->
        </div>
        <!--end ro-->
    </div>
@endsection
