@php
    $pageName = 'System Users';
@endphp

@extends('layouts.backend')

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{ $pageName }}" :createButton="true" module="user" modulePlaceholder="System User" />

    <!-- Page Content -->
    <div class="content  mx-0 w-100">
        <!-- Info -->

        <!-- END Info -->

        <!-- Dynamic Table Full -->
        <div class="block block-rounded">

            <div class="block-content block-content-full">
                <!-- DataTables init on table by adding .js-dataTable-full class, functionality is initialized in js/pages/tables_datatables.js -->
                <div class="table-responsive">

                    <table class="table table-bordered table-striped table-vcenter js-dataTable-full fs-sm">
                        <thead>
                            <tr>
                                <th
                                    class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    User Name
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Email
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Role
                                </th>

                                <th
                                    class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Created Date
                                </th>

                                <th
                                    class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Status
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($listingData as $data)
                                <tr>
                                    <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                                        {{ $data->name }}
                                    </td>
                                    <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                                        {{ $data->email }}
                                    </td>
                                    <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                                        {{ $data->role->role_name }}
                                    </td>
                                    <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                                        {{ $data->created_at }}
                                    </td>
                                    <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                                        @if ($data->is_active)
                                            <div class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                                Active</div>
                                        @else
                                            <div class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-danger-light text-danger cursor-pointer">
                                                Inactive</div>
                                        @endif

                                    </td>
                                    <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                                        <x-reusables.action-buttons :id="$data->id" module="user" :name="$data->name" />
                                    </td>

                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <!-- END Dynamic Table Full -->
    </div>
    <!-- END Page Content -->

    {{-- Password reset modal --}}
    <div class="modal fade" id="forgot-password-modal" tabindex="-1" aria-labelledby="forgot-password-modal"
        style="display: none" aria-modal="true" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="block block-rounded block-transparent mb-0">
                    <div class="block-header block-header-default">
                        <h3 class="block-title">Reset the Password</h3>
                        <div class="block-options">
                            <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
                                <i class="fa fa-fw fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="block-content fs-sm p-5">
                        <form action="{{ url(config('app.admin_prefix') . '/update-user-password') }}" method="POST">
                            @csrf
                            <div class="row ">
                                <div class="col">

                                    <label class="form-label">
                                        <span>User Name</span>
                                    </label>
                                    <input type="hidden" class="company_id" name="user_id" value="">
                                    <input
                                        class="company_name form-control"
                                        placeholder="User Name" readonly type="text" />
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col">
                                    <label class="form-label">
                                        Password*
                                    </label>
                                        <input class="form-control" placeholder="Password" required name="password" type="password" />

                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col">

                                    <label class="form-label"> Confirm Password*</label>
                                        <input
                                            class="form-control"
                                            placeholder="Confirm Password" required name="password_confirmation"
                                            type="password" />

                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col d-flex justify-content-center gap-2">
                                    <button type="button" class="btn btn-sm btn-alt-secondary me-1"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- Reset password modal end --}}
@endsection
