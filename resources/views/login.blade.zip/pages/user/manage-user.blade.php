
@php

    $is_update_form = $formData ? true : false;
    $action_url = $is_update_form ? url(config('app.admin_prefix') . "manage-user/$formData->id") : url(config('app.admin_prefix') . 'manage-user');
    $role_id = old('role_id', $formData->role_id ?? '');
    $is_active = old('is_active', $formData->is_active ?? '');
    $name = old('name', $formData->name ?? '');
    $email = old('email', $formData->email ?? '');
    $pageName = "Manage System User";
@endphp

@extends('layouts.backend' , ['pageName' => "Manage Users"])

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{$pageName}}" :createButton="false" module="user" modulePlaceholder="System User" />
    <div class="content  mx-0 w-100">
        <div class="block block-rounded">
            <div class="block-content block-content-full">
                <x-reusables.badge-alerts/>
                <form action="{{ $action_url }}" method="post">
                    @csrf
                    @if ($is_update_form)
                        @method('PUT')
                    @endif

                    <div class="row mb-4">
                        <div class="col">
                            <label class="form-label" >User Name</label>
                            <input
                                class="form-control "
                                placeholder="User Name" name="name" value="{{ $name }}" type="text" required>
                        </div>
                        <div class="col">
                            <label class="form-label" >Role Name</label>

                            <select name="role_id" class="form-control " >
                                    @foreach ($roles as $role)
                                        <option value="{{$role->id}}" {{decrypt($role->id) == $role_id ? "selected" : ""}} > {{$role->role_name}} </option>
                                    @endforeach
                            </select>
                        </div>
                        <div class="col mt-4">
                            <label class="form-label" for="is_active">Is Active</label>
                            <input
                                placeholder="User Name" id="is_active" name="is_active" value="1" {{$is_active ? "checked" : ""}} type="checkbox" required>
                        </div>
                    </div>
                    @if (!$is_update_form)    
                        <div class="row mb-4" >

                            <div class="col">
                                <label class="form-label" >Email</label>
                                <input
                                    class="form-control"
                                    placeholder="Email Id" name="email" value="{{ $email }}" type="email" required>
                            </div>
                            {{-- <div class="col">
                                <label class="form-label" >Password</label>
                                <input class="form-control "
                                    placeholder="Password" name="password"  type="password" required>
                            </div>
                            <div class="col">
                                <label class="form-label" >Password Confirmation</label>
                                <input class="form-control "
                                    placeholder="Password" name="password_confirmation"  type="password" required>
                            </div> --}}
                        </div>
                    @endif
                    <div class="row ">
                        <div class="col d-flex justify-content-center gap-3">

                            <a href="{{ url(config('app.admin_prefix') . 'users') }}"
                                class="btn btn-secondary">
                                Cancel
                            </a>
                            <button type="submit"
                                class="btn btn-primary">
                                Save
                            </button>
                            
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
@endsection
