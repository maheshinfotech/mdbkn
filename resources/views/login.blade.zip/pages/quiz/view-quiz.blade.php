@php 
$pageName = "Quizes";
@endphp

@extends('layouts.backend' , ['pageName' => "Quizes"])

{{-- @section('js')
  @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
  <x-reusables.app-header pageName="{{$pageName}}" :createButton="true" module="quiz" />
  
  <!-- Page Content -->
  <div class="content  mx-0 w-100">
    <!-- Info -->

    <!-- END Info -->

    <!-- Dynamic Table Full -->
    <div class="block block-rounded">

      <div class="block-content block-content-full">
        <div class="table-responsive">

            <!-- DataTables init on table by adding .js-dataTable-full class, functionality is initialized in js/pages/tables_datatables.js -->
            <table class="table table-bordered table-striped table-vcenter js-dataTable-full fs-sm">
                <thead>
                    <tr>
                        <th
                            class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Questions
                        </th>

                        <th
                            class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Correct Answer
                        </th>
                        
                        <th
                            class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Status
                        </th>
                        <th
                            class="whitespace-nowrap bg-slate-200  font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                            Action
                        </th>
                    </tr>
                </thead>
                <tbody>
                        <tr>
                            <td class="whitespace-nowrap ">
                              What is the approximate range of a D2 Defender?
                            </td>
                            <td class="whitespace-nowrap ">
                                15 inches
                            </td>
                            <td class="whitespace-nowrap ">
                                    <div
                                          class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                          Active</div>
                            </td>
                            <td class="whitespace-nowrap">
                              
                                    <div class="d-flex justify-content-center gap-2">

                                          <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                                <i class="fa fa-edit"></i>
                                          </a>

                                          <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                                <i class="fa fa-trash-alt"></i>
                                          </button>

                                    </div>
                              
                            </td>

                        </tr>
                    
                        <tr>
                            <td class="whitespace-nowrap ">
                              What type of spray pattern does the Defender use?
                            </td>
                            <td class="whitespace-nowrap ">
                                Stream
                            </td>
                            <td class="whitespace-nowrap ">
                                
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                
                            </td>
                            <td class="whitespace-nowrap">
                              <div class="d-flex justify-content-center gap-2">

                                    <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                          <i class="fa fa-edit"></i>
                                    </a>

                                    <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                          <i class="fa fa-trash-alt"></i>
                                    </button>

                              </div>
                            </td>

                        </tr>
                    
                        <tr>
                            <td class="whitespace-nowrap ">
                              Oleoresin Capsicum is a highly inflammatory agent that naturally occurs in:
                            </td>
                            <td class="whitespace-nowrap ">
                                Onions
                            </td>
                            <td class="whitespace-nowrap ">
                                
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                
                            </td>
                            <td class="whitespace-nowrap">
                              <div class="d-flex justify-content-center gap-2">

                                    <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                          <i class="fa fa-edit"></i>
                                    </a>

                                    <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                          <i class="fa fa-trash-alt"></i>
                                    </button>

                              </div>
                            </td>

                        </tr>
                    
                        <tr>
                            <td class="whitespace-nowrap ">
                              What is the percentage of major capsaicinoids in the Defender Heat formulation?
                            </td>
                            <td class="whitespace-nowrap ">
                                0.5%
                            </td>
                            <td class="whitespace-nowrap ">
                                
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                
                            </td>
                            <td class="whitespace-nowrap">
                              <div class="d-flex justify-content-center gap-2">

                                    <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                          <i class="fa fa-edit"></i>
                                    </a>

                                    <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                          <i class="fa fa-trash-alt"></i>
                                    </button>

                              </div>
                            </td>

                        </tr>
                    
                        <tr>
                            <td class="whitespace-nowrap ">
                              How long does it take OC spray to take full effect?
                            </td>
                            <td class="whitespace-nowrap ">
                                Instantly
                            </td>
                            <td class="whitespace-nowrap ">
                                
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                
                            </td>
                            <td class="whitespace-nowrap">
                              <div class="d-flex justify-content-center gap-2">

                                    <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                          <i class="fa fa-edit"></i>
                                    </a>

                                    <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                          <i class="fa fa-trash-alt"></i>
                                    </button>

                              </div>
                            </td>

                        </tr>
                    
                        <tr>
                            <td class="whitespace-nowrap ">
                               How long can the effects of OC last on the average person?
                            </td>
                            <td class="whitespace-nowrap ">
                                5 Minutes
                            </td>
                            <td class="whitespace-nowrap ">
                                
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                
                            </td>
                            <td class="whitespace-nowrap">
                              <div class="d-flex justify-content-center gap-2">

                                    <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                          <i class="fa fa-edit"></i>
                                    </a>

                                    <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                          <i class="fa fa-trash-alt"></i>
                                    </button>

                              </div>
                            </td>

                        </tr>
                    
                        <tr>
                            <td class="whitespace-nowrap ">
                              What is a symptom of OC exposure?
                            </td>
                            <td class="whitespace-nowrap ">
                                Create Escape
                            </td>
                            <td class="whitespace-nowrap ">
                                
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                
                            </td>
                            <td class="whitespace-nowrap">
                              <div class="d-flex justify-content-center gap-2">

                                    <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                          <i class="fa fa-edit"></i>
                                    </a>

                                    <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                          <i class="fa fa-trash-alt"></i>
                                    </button>

                              </div>
                            </td>

                        </tr>
                    
                    
                        <tr>
                            <td class="whitespace-nowrap ">
                              What is the primary goal of OC spray use?
                            </td>
                            <td class="whitespace-nowrap ">
                                Cloughing & Gaggling
                            </td>
                            <td class="whitespace-nowrap ">
                                
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                
                            </td>
                            <td class="whitespace-nowrap">
                              <div class="d-flex justify-content-center gap-2">

                                    <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                          <i class="fa fa-edit"></i>
                                    </a>

                                    <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                          <i class="fa fa-trash-alt"></i>
                                    </button>

                              </div>
                            </td>

                        </tr>
                        <tr>
                            <td class="whitespace-nowrap ">
                              If secondary contamination occurs, you should:
                            </td>
                            <td class="whitespace-nowrap ">
                                Scream & Run
                            </td>
                            <td class="whitespace-nowrap ">
                                
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                
                            </td>
                            <td class="whitespace-nowrap">
                              <div class="d-flex justify-content-center gap-2">

                                    <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                          <i class="fa fa-edit"></i>
                                    </a>

                                    <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                          <i class="fa fa-trash-alt"></i>
                                    </button>

                              </div>
                            </td>

                        </tr>
                        <tr>
                            <td class="whitespace-nowrap ">
                              Oleoresin Capsicum, commonly known as OC spray:
                            </td>
                            <td class="whitespace-nowrap ">
                                Never Works
                            </td>
                            <td class="whitespace-nowrap ">
                                
                                    <div
                                        class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>
                                
                            </td>
                            <td class="whitespace-nowrap">
                              <div class="d-flex justify-content-center gap-2">

                                    <a href="{{url('control-panel/manage-quiz')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                          <i class="fa fa-edit"></i>
                                    </a>

                                    <button data-id="eyJpdiI6IjJBUnJ3NmdlN3RlOS82ZFFVcDJxSGc9PSIsInZhbHVlIjoiRi9PUU5CKzk0NytabTlqV00xQmdmdz09IiwibWFjIjoiZDViMmVhZWUyYTBhZTgwY2VkMWExOTYzYzVjMGY2NjAwNTZiMWJiYmJmNjFjZTljMTc5NGY2ZmY2ZTkxZWMwMCIsInRhZyI6IiJ9" data-module="trainer-class" data-name="Quiz" x-tooltip.error="'Delete Record'" class="delete-record btn text-danger js-swal-confirm">
                                          <i class="fa fa-trash-alt"></i>
                                    </button>

                              </div>
                            </td>

                        </tr>
                    
                </tbody>
            </table>
            
        </div>
      </div>
    </div>
    <!-- END Dynamic Table Full -->
  </div>
  <!-- END Page Content -->
@endsection
