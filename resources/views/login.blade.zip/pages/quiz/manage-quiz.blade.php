
@php

    $is_update_form = $formData ? true : false;
    $action_url = $is_update_form ? url(config('app.admin_prefix') . "manage-role/$formData->id") : url(config('app.admin_prefix') . 'manage-role');
    $role_name = old('role_name', $formData->role_name ?? '');
    $is_active = old('is_active', $formData->is_active ?? '');
    $pageName = "Manage Quizes";

@endphp

@extends('layouts.backend' , ['pageName' => "Manage Quiz"])

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{$pageName}}" :createButton="true" module="quiz" />
    <div class="content  mx-0 w-100">
        <div class="block block-rounded">
            <div class="block-content block-content-full">
                <form action="{{ $action_url }}" method="post">
                    @csrf
                    @if ($is_update_form)
                        @method('PUT')
                    @endif

                  <div class="row">
                        <div class="col">
                              <label class="form-label" >Fill Quiz Details</label>
                              <textarea name="" placeholder="Question" class="form-control"></textarea>
                        </div>
                  </div>

                  <div class="row mt-2">

                        <div class="col">
                            
                            <input  id="is_active" type="text" class="form-control"
                                placeholder="Option 1" > 
                            
                        </div>

                        <div class="col">
                            
                            <input  id="is_active" type="text" class="form-control"
                                placeholder="Option 2" >  
                            
                        </div>

                  </div>

                  <div class="row mt-2">

                        <div class="col">
                            
                                    <input  id="is_active" type="text" class="form-control"
                                          placeholder="Option 3" >
                        
                        </div>

                        <div class="col">
                            
                            <input  id="is_active" type="text" class="form-control"
                                placeholder="Option 4" > 
                            
                        </div>

                  </div>

                  <div class="row mt-4"> 
                        <div class="col">
                              <label for="" class="form-label text-secondary">Choose Correct Option</label>
                              <select name="" class="form-control">
                                    <option value="1">Option 1</option>
                                    <option value="2">Option 2</option>
                                    <option value="3">Option 3</option>
                                    <option value="4">Option 4</option>
                              </select>

                        </div>

                        <div class="col"> 
                              <label class="form-label text-secondary mt-5">
                                    <input type="checkbox" name="is_active">
                                    Active</label>
                        </div>
                  </div>

                  <div class="d-flex justify-content-center  mt-4 p-2 gap-3">
                        <a href="{{ url(config('app.admin_prefix') . 'quiz') }}"
                              class="btn min-w-[7rem] border border-slate-300 font-medium text-slate-700 hover:bg-slate-150 focus:bg-slate-150 active:bg-slate-150/80 dark:border-navy-450 dark:text-navy-100 dark:hover:bg-navy-500 dark:focus:bg-navy-500 dark:active:bg-navy-500/90">
                              Cancel
                        </a>
                        <button type="submit"
                              class="btn min-w-[7rem] bg-primary font-medium text-white hover:bg-primary-focus focus:bg-primary-focus active:bg-primary-focus/90 dark:bg-accent dark:hover:bg-accent-focus dark:focus:bg-accent-focus dark:active:bg-accent/90">
                              Save
                        </button>
                  </div>
                </form>

            </div>
        </div>
    </div>
@endsection
