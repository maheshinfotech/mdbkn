@php
    $pageName =  ucfirst(str_replace('-' , ' ' , $current_type));
@endphp

@extends('layouts.backend')

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{ $pageName }}" :createButton="true" module="order-material/{{$current_type}}" modulePlaceholder="{{$pageName}}" />

    <!-- Page Content -->
    <div class="content  mx-0 w-100">
        <!-- Info -->

        <!-- END Info -->

        <!-- Dynamic Table Full -->
        <div class="block block-rounded">

            <div class="block-content block-content-full">
                <div class="table-responsive">

                    <!-- DataTables init on table by adding .js-dataTable-full class, functionality is initialized in js/pages/tables_datatables.js -->
                    <table class="table table-bordered table-striped table-vcenter js-dataTable-full fs-sm">
                        <thead>
                            <tr>
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Product Title
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Description
                                </th>
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Image
                                </th>

                                {{-- <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Timings
                                </th> --}}

                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Status
                                </th>
                                {{-- <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Change Status
                                </th> --}}
                                <th
                                    class="whitespace-nowrap bg-slate-200 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr>
                                <td class="whitespace-nowrap ">
                                    Product Title
                                </td>
                                <td class="whitespace-nowrap ">
                                    Product Description
                                </td>
                                <td class="whitespace-nowrap ">
                                    <img src="https://st4.depositphotos.com/17110272/23245/i/600/depositphotos_232456216-stock-photo-can-pepper-spray-self-defense.jpg"
                                        style="width:auto;height:60px">
                                </td>
                                {{-- <td class="whitespace-nowrap ">
                                        {{ $course->class_timings }}
                                    </td> --}}
                                <td class="whitespace-nowrap ">

                                    <div class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>

                                </td>
                                {{-- <td class="whitespace-nowrap ">

                                    <button class="btn btn-sm btn-alt-danger">
                                        Make InActive</button>

                                </td> --}}

                                <td class="whitespace-nowrap ">

                                    <div class="d-flex justify-content-center gap-2">

                                        <a href="{{url('control-panel/manage-order-material/training-supplies')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button data-module="order" data-name="Delivery Boy"
                                            x-tooltip.error="'Delete Record'"
                                            class="delete-record btn text-danger js-swal-confirm">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>
                                </td>

                            </tr>
                            <tr>
                                <td class="whitespace-nowrap ">
                                    Product Title
                                </td>
                                <td class="whitespace-nowrap ">
                                    Product Description
                                </td>
                                <td class="whitespace-nowrap ">
                                    <img src="https://st4.depositphotos.com/17110272/23245/i/600/depositphotos_232456216-stock-photo-can-pepper-spray-self-defense.jpg"
                                    style="width:auto;height:60px" >
                                </td>
                                {{-- <td class="whitespace-nowrap ">
                                        {{ $course->class_timings }}
                                    </td> --}}
                                <td class="whitespace-nowrap ">

                                    <div class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>

                                </td>
                                {{-- <td class="whitespace-nowrap ">

                                    <button class="btn btn-sm btn-alt-danger">
                                        Make InActive</button>

                                </td> --}}

                                <td class="whitespace-nowrap ">

                                    <div class="d-flex justify-content-center gap-2">

                                        <a href="{{url('control-panel/manage-order-material/training-supplies')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button data-module="order" data-name="Delivery Boy"
                                            x-tooltip.error="'Delete Record'"
                                            class="delete-record btn text-danger js-swal-confirm">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>
                                </td>

                            </tr>
                            <tr>
                                <td class="whitespace-nowrap ">
                                    Product Title
                                </td>
                                <td class="whitespace-nowrap ">
                                    Product Description
                                </td>
                                <td class="whitespace-nowrap ">
                                    <img src="https://st4.depositphotos.com/17110272/23245/i/600/depositphotos_232456216-stock-photo-can-pepper-spray-self-defense.jpg"
                                    style="width:auto;height:60px">
                                </td>
                                {{-- <td class="whitespace-nowrap ">
                                        {{ $course->class_timings }}
                                    </td> --}}
                                <td class="whitespace-nowrap ">

                                    <div class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-success-light text-success cursor-pointer">
                                        Active</div>

                                </td>
                                {{-- <td class="whitespace-nowrap ">

                                    <button class="btn btn-sm btn-alt-danger">
                                        Make InActive</button>

                                </td> --}}

                                <td class="whitespace-nowrap ">

                                    <div class="d-flex justify-content-center gap-2">

                                        <a href="{{url('control-panel/manage-order-material/training-supplies')}}" x-tooltip.info="'Edit Details'" class="btn text-info">
                                            <i class="fa fa-edit"></i>
                                        </a>

                                        <button data-module="order" data-name="Delivery Boy"
                                            x-tooltip.error="'Delete Record'"
                                            class="delete-record btn text-danger js-swal-confirm">
                                            <i class="fa fa-trash-alt"></i>
                                        </button>

                                    </div>
                                </td>

                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <!-- END Dynamic Table Full -->
    </div>
    <!-- END Page Content -->
@endsection
