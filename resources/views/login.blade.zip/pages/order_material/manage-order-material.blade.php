@php
    
    $is_update_form = $formData ? true : false;
    $action_url = $is_update_form ? url(config('app.admin_prefix') . "manage-instructor/$formData->id") : url(config('app.admin_prefix') . 'manage-instructor');
    $role_id = old('role_id', $formData->role_id ?? '');
    $is_active = old('is_active', $formData->is_active ?? '');
    // $name = old('name', $formData->name ?? '');
    // $email = old('email', $formData->email ?? '');
    // $pageName = 'Manage Order Material';
    $pageName = ucfirst(str_replace('-' , ' ' , $current_type));
    
    $f_name = '';
@endphp

@extends('layouts.backend', ['pageName' => 'Manage Materials'])

{{-- @section('js')
    @vite(['resources/js/pages/datatables.js'])
@endsection --}}

@section('content')
    <x-reusables.app-header pageName="{{ $pageName }}" :createButton="false" module="order-materials" />
    <div class="content  mx-0 w-100">
        <div class="block block-rounded">
            <div class="block-content block-content-full">
                <x-reusables.badge-alerts />
                <form action="{{ $action_url }}" method="post">
                    @csrf
                    @if ($is_update_form)
                        @method('PUT')
                    @endif

                    <div class="row mb-4">
                        <div class="col">
                            <label class="form-label">Product Name</label>
                            <input class="form-control " placeholder="Product Name" name="f_name" value="{{ $f_name }}"
                                type="text" required>
                        </div>
                        <div class="col">
                            <label class="form-label">Product Description</label>
                            <input class="form-control " placeholder="Product Description" name="f_name" value="{{ $f_name }}"
                                type="text" required>
                        </div>
                    </div>
                    <div class="row mb-4">
                              <div class="col text-center">
                                    <input type="file" class="fil-upload form-control">
                                    {{-- <form class="dropzone file-upload" action="be_forms_plugins.html"></form> --}}
                              </div>                        

                    </div>


                    <div class="row mb-4">
                        
                        <div class="col text-center">
                              
                              <input placeholder="Is Active" id="is_active" name="is_active" value="1"
                                  {{ $is_active ? 'checked' : '' }} type="checkbox" required>

                              <label class="form-label" for="is_active">Is Active</label>
                        </div>

                    </div>
    
                    <div class="row ">
                        <div class="col d-flex justify-content-center gap-3">

                            <a href="{{ url(config('app.admin_prefix') . 'ordered-materials') }}" class="btn btn-secondary">
                                Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                Save
                            </button>

                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
@endsection
