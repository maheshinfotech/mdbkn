<span>
    <div class="d-flex justify-content-center gap-2">
        {{-- @click="$notification({text:'This is a simple notification',variant:'success'})" --}}

        @can('update', $module)

            <a href="{{ url(config('app.admin_prefix')."manage-$module/$id") }}" x-tooltip.info="'Edit Details'"
                class="btn text-info">
                <i class="fa fa-edit"></i>
            </a>

            @if($module == 'user')
                <button class="btn text-success update-user-credentials" data-id="{{$id}}" data-name="{{$name}}" >
                    <i class="nav-main-link-icon si si-lock"  data-bs-toggle="modal" data-bs-target="#forgot-password-modal"></i>
                </button>
            @endif


            @if($module == 'class')
                <a href="{{{url(config('app.admin_prefix').'class-detail')}}}" class="btn text-success" data-id="{{$id}}" data-name="{{$name}}" >
                    <i class="fa-solid fa-expand" title="View Class Details"></i>
                </a>
            @endif

        @endcan

        @can('delete', $module)
            <button data-id="{{ $id }}" data-module="{{ $module }}" data-name="{{ $name }}"
                x-tooltip.error="'Delete Record'"
                class="delete-record btn text-danger js-swal-confirm">
                <i class="fa fa-trash-alt"></i>
            </button>
        @endcan

    </div>
</span>
